<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts.base');
});

/** Student Management Routes **/
Route::post('/students', 'StudentsController@store');
Route::get('/students/create', 'StudentsController@create');
Route::post('/students/update', 'StudentsController@update');
Route::get('/students/update', 'StudentsController@show');

Route::get('/departments','DepartmentsController@index');
Route::get('/departments/{id}/students/', 'DepartmentsController@show');

Route::post('/results', 'ResultsController@update');
Route::get('/results/update/{studentId}', 'ResultsController@index');
Route::get('/results/student/{student}', 'ResultsController@getResult');

Route::post('/courses', 'CoursesController@store');
Route::get('/courses', 'CoursesController@index');
Route::post('/courses/update', 'CoursesController@update');
Route::get('courses/update/{courseId}', 'CoursesController@getCourse');
Route::get('/courses/create', 'CoursesController@create');
Route::get('/courses/options', 'CoursesController@optionPage');

/**
 *  GET /students/create
 *  POST /students
 *  
 *  GET /departments
 *
 *
 */
Route::get('/department/all', function() {
    $departments = \App\Department::all();

    return view('results.all_departments', compact('departments'));
});

Route::get('/department/{id}/students/', function($id) {
    $department = \App\Department::find($id);
    $students = \App\Department::find($id)
                       ->hasMany('App\Student', 'dept_id')
                       ->get();

    return view('results.students', compact('students', 'department'));
});