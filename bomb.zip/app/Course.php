<?php

namespace App;

use App\Model;

class Course extends Model
{
    //

    
}
