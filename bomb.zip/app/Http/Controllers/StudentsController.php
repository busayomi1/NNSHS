<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Result;
use App\Student;
use App\Department;
use App\Cummulative; 

class StudentsController extends Controller
{
    public function create()
    {
        $departments = Department::all();        
        return view('students.create', compact('departments'));
    }

    public function store()
    {
        $this->validate(request(), [
            'fullname' => 'required',
            'service_no' => 'required',
        ]);

        $student = Student::create(request(['service_no', 'fullname', 'level', 'dept_id']));
        
        $cummulative = new Cummulative;
        $cummulative->stud_id = $student->id;
        $cummulative->save();

        return redirect('/');
    }

    public function show() 
    {
        $departments = Department::all();
        $studentId = request('student_id');
        $student = Student::where('service_no', $studentId)->first();

        return view('students.show', compact('student', 'departments'));        
    }

    public function update() 
    {
        $this->validate(request(), [
            'fullname' => 'required',
            'service_no' => 'required',
            'rate' => 'required',
            'dept_id' => 'required'
        ]);

        $fullname = request('fullname');
        $service_no = request('service_no');
        $rate = request('rate');
        $department = request('dept_id');

        $student = Student::where('service_no', $service_no)->first();
        $student->fullname = $fullname;
        $student->service_no = $service_no;
        $student->rate = $rate;
        $student->dept_id = $department;
        $student->save();

        return redirect('/');
    }
}
