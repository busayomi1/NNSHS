<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;

class CoursesController extends Controller
{    

    public function index() 
    {
        $courses = Course::all();

        return view('courses.all', compact('courses'));        
    } 

    public function create() 
    {
        return view('courses.create');
    }

    public function update() 
    {
        $this->validate(request(), [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required',
            'course_id' => 'required'
        ]);

        $courseId = request('course_id');
        $title = request('title');
        $code = request('code');
        $unit = request('unit');

        $course = Course::find($courseId);
        $course->title = $title;
        $course->code = $code;
        $course->unit = $unit;
        $course->save();

        return redirect('/');
    }

    public function store() 
    {
        $this->validate(request(), [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required'
        ]);

        Course::create(request(['title', 'code', 'unit']));
        
        return redirect('/');
    }

    public function getCourse($courseId) 
    {
        $course = Course::find($courseId);
        
        return view('courses.update', compact('course'));
    }

    public function optionPage() 
    {
        return view('courses.index');
    }

}
