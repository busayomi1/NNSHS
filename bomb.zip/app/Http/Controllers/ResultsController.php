<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Grade;
use App\Student;
use App\Result;
use App\Course;
use App\GradePoint;
use App\Department;
use App\Cummulative;

use App\Utilities\Utils;


class ResultsController extends Controller
{
    public function index($studentId) 
    {
        $courses  = self::getAllCourses();
        $gradings = self::getGradingSystem();
        $student  = self::getStudent($studentId);
        

        return view('results.create', compact('courses', 'student', 'gradings')); 
    }

    public function getResult(Student $student)
    {
        $session = request('session');
    
        $resultsSemesterOne = $student->hasMany('App\Result', 'stud_id')
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 1]
                                ])
                                ->get();
        $gradePointSemOne = $student->hasMany('App\GradePoint', 'stud_id')
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 1]
                                    ])
                                    ->first();

        $resultsSemesterTwo = $student->hasMany('App\Result', 'stud_id')
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 2]
                                ])
                                ->get();

        $gradePointSemTwo = $student->hasMany('App\GradePoint', 'stud_id')
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 2]
                                    ])
                                    ->first();
        $cummulative = $student->hasOne('App\Cummulative', 'stud_id')->first();

        return view('results.view', compact(
            'student', 'session', 
            'resultsSemesterOne',
            'gradePointSemOne',
            'resultsSemesterTwo',
            'gradePointSemTwo',
            'cummulative'));
    }

    public function update() 
    {
        $exam = request('exam');
        $grade = request('grade');
        $session = request('session');
        $totalScore = request('total');
        $semester = request('semester');
        $courseId = request('course_id');
        $studentId = request('student_id');
        $continiousAssesment = request('continious_assesment');

        $student = Student::find($studentId);
        $selectedCourse = Course::find($courseId);

        $resultObj = new Result;
        $resultObj->EX = $exam;
        $resultObj->LG = $grade;
        $resultObj->TL = $totalScore;
        $resultObj->session = $session;
        $resultObj->stud_id = $studentId;
        $resultObj->semester = $semester;
        $resultObj->course_id = $courseId;
        $resultObj->level = $student->level;
        $resultObj->CA = $continiousAssesment;
        $resultObj->course_unit = $selectedCourse->unit;
        $resultObj->course_title = $selectedCourse->title;
        $resultObj->CP = Utils::calCumulativePoint($selectedCourse->unit, $totalScore);

        $resultObj->save();

        $cummulativePoint = Result::where([
            ['session', '=', $session],
            ['semester', '=', $semester],
            ['stud_id', '=', $studentId]
        ])->sum('CP');


        $cummulativeUnit = Result::where([
            ['session', '=', $session],
            ['semester', '=', $semester],
            ['stud_id', '=', $studentId]
        ])->sum('course_unit');

        $gradePoint = GradePoint::firstOrNew([
            'stud_id' => $studentId,
            'session' => $session,
            'semester' => $semester
        ]);

        $gradePoint->CP = $cummulativePoint;
        $gradePoint->CU = $cummulativeUnit;
        $gradePoint->GPA = Utils::calGradePoint($cummulativePoint, $cummulativeUnit);
        $gradePoint->save();

        $ccPoint = GradePoint::where('stud_id', $studentId)->sum('CP');
        $ccUnit = GradePoint::where('stud_id', $studentId)->sum('CU');

        $cummulative = Cummulative::where('stud_id', $studentId)->first();
        $cummulative->CCU = $ccUnit;
        $cummulative->CCP = $ccPoint;
        $cummulative->CGPA = Utils::calGradePoint($ccPoint, $ccUnit);
        $cummulative->save();

        return redirect('/');
        
    }

    private function processResult() 
    {
        
    }

    private function getStudent($id) 
    {
        return Student::find($id);
    }

    private function getGradingSystem()
    {
        return Grade::all();
    }

    private function getAllCourses() 
    {
        return Course::all();
    }    
}
