<?php

namespace App\Utilities;

use App\Grade;

final class Utils 
{
  
  public static function calGradePoint($cumulativePoint, $cumulativeUnit)
  {
      return $cumulativePoint / $cumulativeUnit;
  }

  public static function calCumulativePoint($courseUnit, $totalScore)
  {
      if ($totalScore >= 75)
        return $courseUnit * 4.00;
      
      if ($totalScore >=70 && $courseUnit <= 74)
        return $courseUnit * 3.50;

      if ($totalScore >= 65 && $totalScore <=69)
        return $courseUnit * 3.25;

      if ($totalScore >= 60 && $totalScore <= 64)
        return $courseUnit * 3.00;

      if ($totalScore >= 55 && $totalScore <= 59)
        return $courseUnit * 2.75;  

      if ($totalScore >= 50 && $totalScore <= 54)
        return $courseUnit * 2.50;

      if ($totalScore >= 45 && $totalScore <= 49)
        return $courseUnit * 2.25;

      if ($totalScore >= 40 && $totalScore <= 44)
        return $courseUnit * 2.00;

      if ($totalScore < 40)
        return $courseUnit * 0.00;
  }

}