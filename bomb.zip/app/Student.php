<?php

namespace App;

use App\Model;

class Student extends Model
{
        
}
