  <?php $__env->startSection('other_css'); ?>
    <style>
      .container {
         width: 1000px;
         min-height: 700px;
         background: white;
         padding: 20px 50px 20px 50px;
      }
      .result_heading { 
        text-align: center; 
      }

      .name_details {
          
          
      }

      .search_box {
        float: right;
        clear: both;
      }

      .grade_points h5, .grade_points h4 {
          display: inline-block;
          padding: 10px 30px 0px 0px;
      }

      @media  print {
        .search_box {
          display: none;
        }

        .print_box {
          display: none;
        }

      }

    </style>

  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('content'); ?>
    
    <br><br><br><br><br><br><br><br>
    <div class="container">
      
      <div>
          <div class="result_heading">
            <h1>Student Result</h1>
          <div>

          <div>
            <h3><?php echo e($session); ?> session</h3>
          </div>
                
           
           <div>
              <a class="nonblock nontext rgba-background clearfix grpelem" id="u348-4" href="/"><!-- content --><p>Back To Home</p></a>
              <div class="search_box">
                <form class="form-inline" action="/results/student/<?php echo e($student->id); ?>">
                  <div class="form-group">
                    <input name="session" type="number" value="<?php echo e($session); ?>" class="form-control" placeholder="2015">
                  </div>
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="search">
                  </div>
                </form>
              </div>
           
              <br><br><br>
              <div class="name_details">
                <h2><?php echo e($student->fullname); ?></h3>
                <h4><?php echo e($student->service_no); ?></h5>
              </div>

           </div>
           

          
           <br><br>
          <div style="text-align: left;">
            <?php if(count($resultsSemesterOne)): ?>
                <div style="padding: 20px 0px 20px 0px;"><h4>First Semester</h4></div>
                <table class="table">

                  <thead>
                    <th>Course title</th>
                    <th>Unit</th>
                    <th>Total Score</th>
                    <th>Grade</th>
                    <th>Cummulative Point</th>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $resultsSemesterOne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($result->course_title); ?></td>
                      <td><?php echo e($result->course_unit); ?></td>
                      <td><?php echo e($result->TL); ?></td>
                      <td><?php echo e($result->LG); ?></td>
                      <td><?php echo e($result->CP); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                
                </table>

                <div style="margin: 30px 0px;">
                  <div class="grade_points">
                    <h5>CU: <?php echo e($gradePointSemOne->CU); ?></h5>
                    <h5>CP: <?php echo e($gradePointSemOne->CP); ?></h5>
                    <h4>GP: <?php echo e($gradePointSemOne->GPA); ?></h4>
                  </div>
                </div>

            <?php endif; ?>
          </div>   
          <div style="text-align: left;">
            <?php if(count($resultsSemesterTwo)): ?>
                <div style="padding: 20px 0px 20px 0px;"><h4>Second Semester</h4></div>
                <table class="table">

                  <thead>
                    <th>Course title</th>
                    <th>Unit</th>
                    <th>Total Score</th>
                    <th>Grade</th>
                    <th>Cummulative Point</th>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $resultsSemesterTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($result->course_title); ?></td>
                      <td><?php echo e($result->course_unit); ?></td>
                      <td><?php echo e($result->TL); ?></td>
                      <td><?php echo e($result->LG); ?></td>
                      <td><?php echo e($result->CP); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                
                </table>

                <div style="margin: 30px 0px;">
                  <div class="grade_points">
                    <h5>CU: <?php echo e($gradePointSemTwo->CU); ?></h5>
                    <h5>CP: <?php echo e($gradePointSemTwo->CP); ?></h5>
                    <h5>GP: <?php echo e($gradePointSemTwo->GPA); ?></h5>
                  </div>
                </div>

            <?php endif; ?>

            <?php if(count($resultsSemesterOne) || count($resultsSemesterTwo)): ?>
              <div class="grade_points">
                  <h5>CCU: <?php echo e($cummulative->CCU); ?></h5>
                  <h5>CCP: <?php echo e($cummulative->CCP); ?></h5>
                  <h4>CGPA: <?php echo e($cummulative->CGPA); ?></h4>
                </div>
            <?php endif; ?>
          </div>   
          
          <div class="print_box" style="float: right">
            <button id="print" class="btn btn-success">Print result</button>
          </div>
      </div>

    </div>
  
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>

    var PrintApp = {
        init: function() {
           var button = document.getElementById('print');
           
           button.addEventListener('click', function(event) {
              window.print();
           }, false);
        }
    }

    window.addEventListener('load', function(event) {
        var app = Object.create(PrintApp);
        app.init();
    }, false);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>