<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGradePointsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grade_points', function (Blueprint $table) {
            $table->increments('id');
            $table->integer("CU")->default(0);
            $table->double("CP")->default(0);
            $table->double("GPA")->default(0.0);
            $table->integer('session')->nullable();
            $table->integer("semester")->default(0);
            
            $table->integer('stud_id');

            $table->foreign('stud_id')
                  ->references('id')
                  ->on('students')
                  ->onDelete('cascade');
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grade_points');
    }
}
