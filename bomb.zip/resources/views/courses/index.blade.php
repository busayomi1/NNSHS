@extends('layouts.master')

    @section('other_css')
        <link rel="stylesheet" type="text/css" href="/css/index_two.css?4010516454" id="pagesheet"/>
    @endsection

    @section('content')
    <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u75-bw">
     <div id="u75"><!-- group -->
      <div class="clearfix" id="u75_align_to_page">
       <div class="clearfix grpelem" id="pu76-4"><!-- column -->
        <div class="clearfix colelem" id="u76-4"><!-- content -->
         <p style="color: #fff; text-align:left; font-size: 25px;">NIGERIAN NAVY SCHOOL OF HEALTH SCIENCES</p>
        </div>
        
       </div>
      </div>
     </div>
    </div>
    <br><br><br>
       <div class="clearfix colelem" id="pu125"><!-- group -->
       <br><br>
     <div class="clip_frame grpelem" id="u125"><!-- image -->
      <img class="block" id="u125_img" src="/images/0003-home3.png" alt="" width="26" height="26"/>
     </div>
     <div class="rgba-background clearfix grpelem" id="u124-4"><!-- content -->
      <a href="/">Back To Home</a>
     </div>
    </div>
    <div class="browser_width colelem" id="u88-4-bw">
    <br>

     <div class="clearfix" id="u88-4"><!-- content -->
      <p id="u88-2"><span class="Heading" id="u88">Course Management</span></p>
     </div>
    </div>
    <div class="clearfix colelem" id="pu90"><!-- group -->
     <a class="nonblock nontext rgba-background clearfix grpelem" id="u90" href="/courses/create"><!-- column --><div class="position_content" id="u90_position_content"><div class="clip_frame colelem" id="u91"><!-- image --><img class="block" id="u91_img" src="/images/0050-folder-plus.png" alt="" width="64" height="64"/></div><div class="clearfix colelem" id="u93-4"><!-- content --><p>Add New Course</p></div></div></a>
     <a class="nonblock nontext rgba-background clearfix grpelem" id="u102" href="/courses"><!-- column --><div class="position_content" id="u102_position_content"><div class="clip_frame colelem" id="u103"><!-- image --><img class="block" id="u103_img" src="/images/23-512.png" alt="" width="64" height="64"/></div><div class="clearfix colelem" id="u105-4"><!-- content --><p>Update Existing Course</p></div></div></a>
    </div>
    <div class="verticalspacer"></div>
   
   </div>
  </div>
    @endsection

    @section('scripts')

    @endsection