@extends('administrator.master')

@section('content')

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">New course</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/courses" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/courses/update" method="POST">
                
                {{ csrf_field() }}
                <input name="course_id" value="{{ $course->id }}" hidden/>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="text" name="title" value="{{ $course->title }}">
                    <label class="mdl-textfield__label" for="title">Title</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" name="code" value="{{ $course->code }}">
                    <label class="mdl-textfield__label" for="code">Code</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="number" name="unit" value="{{ $course->unit }}">
                    <label class="mdl-textfield__label" for="unit">Unit</label>
                </div>

                <br>
                <!-- Departments go here -->

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-clipboard-outline"></span>&nbsp;&nbsp; update</button>
            </form>
        </div>
    </div>

@endsection