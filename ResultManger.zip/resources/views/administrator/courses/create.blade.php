@extends('administrator.master')

@section('content')

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">New course</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/courses" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        @include('administrator.errors')

        <div class="page-content-frame">
            <div class="">
                <form class="" action="/courses" method="POST">
                    
                    {{ csrf_field() }}

                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input"  type="text" name="title">
                        <label class="mdl-textfield__label" for="title">Title</label>
                    </div>

                    <br>

                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input" type="text" name="code">
                        <label class="mdl-textfield__label" for="code">Code</label>
                    </div>

                    <br>

                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input"  type="number" name="unit">
                        <label class="mdl-textfield__label" for="unit">Unit</label>
                    </div>

                    <br>
                
                    <div class="select-field">
                        <label style="color:lightcoral;">Hold the ctrl key to select multiple departments</label>
                        <br>
                        <select name="department_id[]" multiple>
                            <option selected disabled>Please select department</option>
                            @foreach($departments as $department)
                            <option value="{{ $department->id }}">{{ $department->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <br>

                    <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-clipboard-check"></span> create</button>
                </form>
            </div>
        </div>
    </div>

@endsection