@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage Courses</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/courses/create" class="mdl-button mdl-button--raised"><span class="mdi mdi-clipboard-plus"></span>&nbsp;&nbsp; new course</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Id</th>
                        <th class="mdl-data-table__cell--non-numeric">Title</th>
                        <th class="mdl-data-table__cell--non-numeric">Code</th>
                        <th class="mdl-data-table__cell--non-numeric">Unit</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($courses as $course)
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric">{{ $course->id }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $course->title}}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $course->code }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $course->unit }}</td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/courses/update/{{ $course->id}}/" class="mdl-button mdl-button--colored">update</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    
@endsection