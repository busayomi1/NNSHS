@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage students</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/students/create" class="mdl-button mdl-button--raised mdl-button--colored"><span class="mdi mdi-clipboard-plus"></span>&nbsp;&nbsp; new student</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        <th class="mdl-data-table__cell--non-numeric">Level</th>
                        <th class="mdl-data-table__cell--non-numeric">Rate</th>
                        <th class="mdl-data-table__cell--non-numeric">Department</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($students as $student)
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->service_no }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->fullname }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->level->code }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->rate }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->department->name }}</td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/students/{{ $student->id }}/edit" class="mdl-button mdl-button--colored">edit</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    
@endsection