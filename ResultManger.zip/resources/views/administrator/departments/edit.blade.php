@extends('administrator.master')

@section('content')

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">Edit Department</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/departments/update/{{ $department->id }}" method="POST">
                
                {{ csrf_field() }}

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="text" name="name" value="{{ $department->name }}">
                    <label class="mdl-textfield__label" for="name">Title</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" name="code" value="{{ $department->code }}">
                    <label class="mdl-textfield__label" for="code">Code</label>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-bank"></span> update</button>
            </form>
        </div>

        @include('administrator.errors')
    </div>

@endsection