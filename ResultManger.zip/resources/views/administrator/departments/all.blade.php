@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage Departments</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments/create" class="mdl-button mdl-button--raised mdl-button--colored"><span class="mdi mdi-bank"></span>&nbsp;&nbsp; create department</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Id</th>
                        <th class="mdl-data-table__cell--non-numeric">Name</th>
                        <th class="mdl-data-table__cell--non-numeric">Code</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($departments as $department)
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric">{{ $department->id }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $department->name }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $department->code }}</td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/departments/{{ $department->id }}/edit" class="mdl-button mdl-button--colored">edit</a>
                                <a href="/departments/{{ $department->id }}/students" class="mdl-button mdl-button--colored">view students</a>
                                <a href="/departments/{{ $department->id }}/courses" class="mdl-button mdl-button--colored">
                                    <span class="mdi mdi-slate"></span>&nbsp;&nbsp; manage courses
                                </a> 
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    
@endsection