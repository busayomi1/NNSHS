@extends('administrator.master')

@section('content')
  <section class="content">
    <header class="greeting-text-frame">
      <h4>Courses offered</h4>
      <div class="divider"></div>
      <div class="sub-controls">
        <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back</a>
      </div>
    </header>

    <div class="page-content-frame">
      <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
          <thead>
              <tr>
                  <th class="mdl-data-table__cell--non-numeric">Id</th>
                  <th class="mdl-data-table__cell--non-numeric">Code</th>
                  <th class="mdl-data-table__cell--non-numeric">Title</th>
                  <th class="mdl-data-table__cell--non-numeric">Level</th>
                  <th class="mdl-data-table__cell--non-numeric">Semester</th>
                  <th class="mdl-data-table__cell--non-numeric">Action</th>
              </tr>
          </thead>
          <tbody>
          @foreach ($courses as $course)
              <tr>
                <td class="mdl-data-table__cell--non-numeric">{{ $course->id }}</td>
                <td class="mdl-data-table__cell--non-numeric">{{ $course->code }}</td>
                <td class="mdl-data-table__cell--non-numeric">{{ $course->title }}</td>
                <td class="mdl-data-table__cell--non-numeric">
                  @foreach ($course->levels as $level)
                    {{ $level->code ? $level->code : 'not assigned' }} &nbsp;
                  @endforeach
                </td>
                <td class="mdl-data-table__cell--non-numeric">
                  <span >{{ $course->semester ? $course->semester->code : 'not assigned' }}
                  <span>
                </td>
                <td>
                  <a href="/departments/{{ $department->id }}/courses/{{ $course->id }}/edit" class="mdl-button mdl-button--colored">edit</a>
                </td>
              </tr>
          @endforeach
          </tbody>
      </table>
    </div>

  </section>
@endsection