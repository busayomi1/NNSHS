@extends('administrator.master')

@section('content')
  <section class="content">
    <header class="greeting-text-frame">
      <h4>Assign semester and level</h4>
      <div class="divider"></div>
      <div class="sub-controls">
        <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back</a>
      </div>
    </header>

    <div class="page-content-frame">
      <div>
        <form action="/departments/courses/" method="POST">
          {{ csrf_field() }}
          <input type="hidden" name="course" value="{{ $course->id }}">
          <input type="hidden" name="department" value="{{ $department->id }}">
          
          <div style="margin: auto auto 30px auto">
            <h5 style="margin: auto auto 30px auto">Select semester to assign course</h5>
              @foreach ($semesters as $semester)
              <label for="semester">
                {{ $semester->title }}
                <input type="radio" checked name="semester" value="{{ $semester->code }}">
              </label>
            @endforeach
          </div>

          <div>
            <h5>Select level</h5>
            <label>
              <select name="level">
                  <option selected disabled>select level</option>
                  @foreach($levels as $level)
                  <option value="{{ $level->id }}">{{ $level->code }}</option>
                  @endforeach
              </select>
            </label>
          </div>
         

          <div style="padding: 30px 0px 30px 0px">
            <input class="mdl-button mdl-button--raised mdl-button--colored" type="submit" value="assign">
          </div>
        </form>
      </div>
    </div>
  </section>
@endsection

