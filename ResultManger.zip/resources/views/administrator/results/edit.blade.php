@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Edit Student Result</h4>

            <form class="sub-form" action="/results/{{ $department->id }}/{{ $student->id }}/edit">    
               
               <label>Session</label>
               <select name="session">
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
               </select>

               <label>Semester</label>
               <select name="semester">
                    <option value="1">1</option>
                    <option value="2">2</option>
               </select>
               
               <label>Course</label>
               <select name="course_id">
                   @foreach($courses as $course)
                    <option value="{{ $course->id }}">{{ $course->title }}</option>
                   @endforeach
               </select>

               <button class="mdl mdl-button mdl-button--raised mdl-button--colored">search</button>
            </form>
            <div class="divider"></div>
            <div class="student-detail">
                <h4><span class="mdi mdi-account"></span>&nbsp;&nbsp;{{ $student->fullname }}</h4>
                <h6>{{ $student->service_no }}</h6>
            </div>
        </header>

        @if($result)
        <div class="page-content-frame">
           <div class="demo-form-card mdl-card  form-container">
                <form action="/results/update" method="POST">
                    {{ csrf_field() }}
                    <input type="text" hidden name="level_id" value="{{ $student->level->id }}">
                    <input type="text" hidden name="student_id" value="{{ $student->id }}">
                    <input type="text" hidden name="department_id" value="{{ $department->id }}">

                    <div class="select-field">
                        <select name="course_id">
                            <option selected disabled>Please select course</option>
                            @foreach($courses as $course)
                                @if($result->title == $course->title)
                                    <option selected value="{{ $result->pivot->course_id }}">{{ $result->pivot->title }}</option>
                                @else
                                    <option value="{{ $course->id }}">{{ $course->title }}</option>
                                @endif                                
                            @endforeach
                        </select>
                    </div>

                    <div class="select-field">
                        <select name="session">
                            @for($i = 2015; $i <= 2020; $i++)
                                @if($result->pivot->session == $i)
                                    <option selected value="{{ $result->pivot->session }}">{{ $result->pivot->session }}</option>
                                @else
                                    <option value="{{ $i }}">{{ $i }}</option>
                                @endif
                            @endfor                           
                        </select>
                    </div>

                    <div class="select-field">
                        <select name="semester">
                           @for($i = 1; $i <= 2; $i++)
                                @if($result->pivot->semester == $i)
                                    <option selected value="{{ $result->pivot->semester }}">{{ $result->pivot->semester }}</option>
                                @else
                                    <option value="{{ $i }}">{{ $i }}</option>
                                @endif

                           @endfor
                        </select>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" id="continious_assesment" name="ca" required value="{{ $result->pivot->ca }}">
                        <label class="mdl-textfield__label" for="ca">CA Score</label>
                    </div>

                    <br>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" id="exam" name="exam" required value="{{ $result->pivot->exam }}">
                        <label class="mdl-textfield__label" for="code">Exam score</label>
                    </div>

                     <br>

                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input" type="number" id="total" name="total" value="{{ $result->pivot->total }}" readonly>
                        <label class="mdl-textfield__label" for="code"></label>
                    </div>

                    <br>

                    <div class="select-field">
                        <div class="mdl-textfield mdl-js-textfield">
                            <input class="mdl-textfield__input" type="text" id="grade" name="lg" value="{{ $result->pivot->lg }}" readonly>
                            <label class="mdl-textfield__label" for="grade"></label>
                        </div>
                    </div>

                    <br>
                    <br>

                    <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-folder-outline"></span>&nbsp;&nbsp;update</button>
                </form>
           </div>
        </div>
        @endif
    </div>
        @include('administrator.errors')
</div>

@section('scripts')
    <script src="/js/grader.js"></script>
@endsection
    
@endsection