<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="/css/material.min.css" rel="stylesheet">
        <link href="/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="/css/fonts.css" rel="stylesheet">
        <link href="/css/admin.css" rel="stylesheet">

        <style>

            .head {
                font-family: 'Roboto Bold';
            }
            .print_section {
                margin: 50px 70px 100px 805px;
            }
            .logo-text, .heading { 
                text-align: center;
            }
            
            .logo-text h3 { 
                display: inline-block;
            }

            .logo-text h5 {
                margin: -10px auto auto auto;
            }

            .content {
                padding: 50px;
                background: white;
                margin: auto;
            }

            .results_box {
                margin: -20px auto;
                width: 800px;
            }

            .semester-title {
                font-family: 'Roboto SemiBold';
                padding: 20px 0px 20px 0px;
            }

            .grade_points h5 {
                font-size: 16px;
                display: inline-block;
                padding: 10px 20px 10px 0px;
            }

            .name_details {
                margin: auto;
            }

            .filter {
                position: fixed;
                left: 1100px;
                top: 115px;
                z-index: 100;
                padding: 20px;;
                background: #efefef;
                border-radius: 2px;
            }

            .sub-form > * {
                display: block;
                margin: auto auto 10px auto;
            }

            .sub-form > label {
                margin-left: -5px;
            }

            .sub-form > button {
                margin: 15px auto 2px 1px;
            }

            .name_details {
                padding: 30px;
                text-align: center;
            }

            .name_details h3 {
                font-size: 29px;
                display: inline-block;
                padding: 10px 30px;
                font-family: 'Roboto SemiBold';
            }

            .name_details h6 {
                font-size: 14px;
                font-family: "Roboto SemiBold";
                margin-top: -10px;
            }

            @media print {
                .filter {
                    display: none;
                }

                .print_section {
                    display: none;
                }
            }
        </style>

    </head>
    
    <body>
        <main class="content">
            <header class="logo-text">
                <img src="/images/logo.png" width="90" heigh="90">
                <h3>Nigerian Navy School of Health Sciences</h3>
                <h5>Irra Road, Offa Kwara State</h5>
            </header>
            
             <div class="name_details">
                <h3>Department of {{ $department->name }}</h4>
            </div>            

            <div class="filter">
                <form class="sub-form" action="/results/department/{{ $department->id }}">

                    <label>Level</label>
                    <select name="level">
                        @foreach($classes as $class)
                            @if ($level->id == $class->id)
                             <option selected value="{{ $level->id }}">{{ $level->title }}</option>
                            @else
                             <option value="{{ $class->id }}">{{ $class->title }}</option>
                            @endif
                        @endforeach
                    </select>
                   
                    <label>Semester</label>
                    <select name="semester">
                        @for ($i = 1; $i <= 2; $i++)
                            @if ($semester == $i)
                                <option selected value="{{$semester}}">{{$semester}}</option>
                            @else
                                <option value="{{$i}}">{{$i}}</option>
                            @endif
                        @endfor
                    </select>

                    <label>Session</label>
                    <select name="session">
                     @for($i = 2015; $i <= 2025; $i++)
                        @if ($session == $i)
                         <option selected value="{{ $session }}">{{ $session }}</option>
                        @else
                         <option value="{{$i}}">{{$i}}</option>
                        @endif
                     @endfor
                    </select>

                    <button class="mdl mdl-button mdl-button--raised mdl-button--colored">filter</button>
                </form>
            </div>

        @if ([] !== $courses && [] !== $results)
        <section class="results_box">
            <div>
                <h5 class="head">{{ $level->title }}</h5>
            </div>
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        
                        <strong>
                            <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        </strong>
                        
                        @foreach($courses as $course)
                            <strong>
                                <th class="mdl-data-table__cell--non-numeric">{{ $course->code }}</th>
                            </strong>                            
                        @endforeach

                        <th class="mdl-data-table__cell--non-numeric"><strong>GPA</strong></th>
                        
                    </tr>
                </thead>

                <tbody>
                    
                    @foreach($results as $result) 
                    <tr>
                        <td class="mdl-data-table__cell--non-numeric">{{ $result->get('name') }}</td>
                        
                        @if([] !== $result->get('result')->all())
                            @foreach($result->get('result') as $res)
                            <td class="mdl-data-table__cell--non-numeric">
                                {{ $res->pivot->lg }}
                            </td>
                            @endforeach
                        @else
                            @for($i = 0; $i < count($courses); $i++) 
                            <td class="mdl-data-table__cell--non-numeric">{{ '-' }}</td>
                            @endfor
                        @endif
                        
                        <td class="mdl-data-table__cell--non-numeric">
                            {{ (null !== $result->get('grade_point')) 
                                ? number_format($result->get('grade_point')->gpa, 2) 
                                : '-' 
                            }}
                        </td>
                    </tr>
                    @endforeach

                </tbody>
            </table>
        </section>
    
        @endif

        <section class="print_section">
            <a href="/department/{{$department->id}}/students" class="mdl-button mdl-button--colored">
                <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back
            </a>
            <button id="print" class="mdl mdl-button mdl-button--raised mdl-button--colored">print</button>            
        </section>

    </section>

        <script>
            window.addEventListener('load', function(event) {
                var printButton = document.getElementById('print');
                printButton.addEventListener('click', function(event) {
                    window.print();
                })
            })
        </script>
    </body>

</html>

   