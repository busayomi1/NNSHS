<h2>Duplicate record found<h2>
<h3>Please use the Edit option to change a particular result</h3>