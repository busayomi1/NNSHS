@extends('administrator.master')

@section('css')
  <style>
    .error-container {
      color: #fff;
      width: 700px;
      text-align: center;
      border-radius: 4px;
      background: lightcoral;
      margin: 10% auto auto auto;
      padding: 20px 20px 35px 30px; 
    }

    .redirect-controls {
      color: #ffffff;
    }

    .redirect-controls > a {
      color: #ffffff;
    }
  </style>
@endsection

@section('content')
  <div class="error-container">
    <h3>Duplicate record found</h3>  
    <h4>Please use the Edit option to change a particular result</h4>

    <h3>
      @foreach($errors->all() as $error)
        {{ $error }}
      @endforeach
    </h3>
    <div class="redirect-controls">
      <a href="/department/{{$department}}/students" class="mdl-button"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
    </div>
  </div>
@endsection
