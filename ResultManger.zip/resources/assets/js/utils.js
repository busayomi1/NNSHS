
window.addEventListener('load', function(event) {
    let timer = document.getElementById('current-date');
    let date = new Date().toGMTString();
    timer.innerHTML = date.substring(0, date.length - 12);
});