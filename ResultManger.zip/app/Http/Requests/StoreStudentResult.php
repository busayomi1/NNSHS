<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreStudentResult extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'lg' => 'required',
            'ca'=> 'required',
            'exam' => 'required',
            'total' => 'required',
            'semester' => 'required',
            'session' => 'required',
            'student_id' => 'required',
            'course_id' => 'required',
            'level_id' => 'required',
            'department_id' => 'required'
        ];
    }
}
