<?php

namespace App\Http\Controllers;

use App\Course;
use App\Student;
use App\Department;
use App\GradePoint;
use App\Cummulative;
use App\Utilities\Utils;
use App\Http\Requests\StoreStudentResult;
use App\Interfaces\StudentResultProcessor;
use Illuminate\Http\Request;
use Illuminate\Database\QueryException;

class StudentResultsController extends Controller
{
    
	public function __construct()
	{
		$this->middleware('auth');
	}

    public function show(Student $student, Request $request)
    {
        $session = $request->session;
        if ($session == NULL) {
            $session = 2015;
        }

        $department = Department::find($student->department->id);

        $resultsSemesterOne = $student->results()
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 1]
                                ])
                                ->get();
        $gradePointSemOne = $student->gradePoints()
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 1]
                                    ])
                                    ->first();

        $resultsSemesterTwo = $student->results()
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 2]
                                ])
                                ->get();

        $gradePointSemTwo = $student->gradePoints()
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 2]
                                    ])
                                    ->first();
        $cummulative = $student->cummulative()->first();

        return view('administrator.results.show', compact(
            'student', 'session', 
            'resultsSemesterOne',
            'gradePointSemOne',
            'resultsSemesterTwo',
            'gradePointSemTwo',
            'cummulative',
            'department', 'session'));
    }

    public function create(Department $department, Student $student)
    {
    	$courses = $department->courses()->where('level_id', $student->level_id)->get();        
    	return view('administrator.results.create', compact('department', 'student', 'courses'));	
    }

    public function store(StoreStudentResult $request)
    {
        $processor = new StudentResultProcessor($request);
        try 
        {
            $processor->saveResult();
        }
        catch(QueryException $exception) 
        {
            return response()->view('errors.500', ["department" => $request->department_id], 500);
        }
        
        $processor->updateGradePointAverage();
        $processor->updateCummulativeGradePointAverage();

        return redirect("/results/$request->department_id/$request->student_id");
    }

    public function edit(Department $department, Student $student, Request $request)
    {
        $courses = $department->courses;
        $result = $student->results()->where([
            'session' => $request->session,
            'semester' => $request->semester,
            'course_id' => $request->course_id
        ])->first();

        $request->session()->put('session', $request->session);
        $request->session()->put('semester', $request->semester);
        $request->session()->put('course_id', $request->course_id);

        return view('administrator.results.edit', compact('student', 'courses', 'department', 'result'));
    }

    public function update(Request $request) 
    {
        $processor = new StudentResultProcessor($request);
        $processor->updateResult();
        $processor->updateGradePointAverage();
        $processor->updateCummulativeGradePointAverage();
        return redirect("results/$request->department_id/$request->student_id/edit");
    }
 
}
