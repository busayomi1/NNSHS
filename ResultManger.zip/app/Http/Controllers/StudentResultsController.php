<?php

namespace App\Http\Controllers;

use App\Course;
use App\Student;
use App\Department;
use App\GradePoint;
use App\Cummulative;
use App\Utilities\Utils;
use App\Http\Requests\StoreStudentResult;

use Illuminate\Http\Request;

class StudentResultsController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

    public function show(Student $student, Request $request)
    {
        $session = $request->session;
        if ($session == NULL) {
            $session = 2015;
        }

        $department = Department::find($request->session()->get('department'));

        $resultsSemesterOne = $student->results()
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 1]
                                ])
                                ->get();
        $gradePointSemOne = $student->gradePoints()
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 1]
                                    ])
                                    ->first();

        $resultsSemesterTwo = $student->results()
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 2]
                                ])
                                ->get();

        $gradePointSemTwo = $student->gradePoints()
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 2]
                                    ])
                                    ->first();
        $cummulative = $student->cummulative()->first();

        return view('administrator.results.show', compact(
            'student', 'session', 
            'resultsSemesterOne',
            'gradePointSemOne',
            'resultsSemesterTwo',
            'gradePointSemTwo',
            'cummulative',
            'department', 'session'));
    }

    public function create(Department $department, Student $student)
    {
    	$courses = $department->courses;
    	return view('administrator.results.create', compact('department', 'student', 'courses'));	
    }

    public function store(StoreStudentResult $request)
    {
        $course  = Course::find($request->course_id); 
        
        $student = Student::find($request->student_id);
        $student->results()->attach($request->course_id, [
            'ca' => $request->ca,
            'exam' => $request->exam,
            'total' => $request->total,
            'lg' => $request->lg,
            'unit' => $course->unit,
            'title' => $course->title,
            'semester' => $request->semester,
            'session' => $request->session,
            'level_id' => $request->level_id,
            'department_id' => $request->department_id,
            'cp' => Utils::calCumulativePoint($course->unit, $request->total)
        ]);

        $cummulativePoint = $student->results()->where([
            ['session', '=', $request->session],
            ['semester', '=', $request->semester],
            ['student_id', '=', $request->student_id]
        ])->sum('cp');

        $cummulativeUnit = $student->results()->where([
            ['session', '=', $request->session],
            ['semester', '=', $request->semester],
            ['student_id', '=', $request->student_id]
        ])->sum('results.unit');

        $gradePoint = GradePoint::firstOrNew([
            'student_id' => $request->student_id,
            'session' => $request->session,
            'semester' => $request->semester
        ]);

        $gradePoint->fill([
            'cu' => $cummulativeUnit,
            'cp' => $cummulativePoint,
            'gpa' => Utils::calGradePoint($cummulativePoint, $cummulativeUnit)
        ]);
        $gradePoint->save();

        $ccPoint = GradePoint::where('student_id', $request->student_id)->sum('cp');
        $ccUnit  = GradePoint::where('student_id', $request->student_id)->sum('cu');

        $cummulative = Cummulative::where('student_id', $request->student_id)->first();
        $cummulative->fill([
            'ccu' => $ccUnit,
            'ccp' => $ccPoint,
            'cgpa' => Utils::calGradePoint($ccPoint, $ccUnit)
        ]);
        $cummulative->save();

        return redirect("/results/$request->department_id/$request->student_id");
    }

    public function edit(Department $department, Student $student, Request $request)
    {
        $courses = $department->courses;
        $result = $student->results()->where([
            'session' => $request->session,
            'semester' => $request->semester,
            'course_id' => $request->course_id
        ])->first();

        $request->session()->put('session', $request->session);
        $request->session()->put('semester', $request->semester);
        $request->session()->put('course_id', $request->course_id);

        return view('administrator.results.edit', compact('student', 'courses', 'department', 'result'));
    }

    public function update(Request $request) 
    {
        $course  = Course::find($request->course_id); 
        
        $student = Student::find($request->student_id);

        $result = $student->results()->where([
            'session' => $request->session()->get('session'),
            'semester' => $request->session()->get('semester'),
            'course_id' => $request->course_id
        ])->first();

        $rowIdToUpdate = $result->pivot->id;
        $student->results()->newPivot()->where('id', $rowIdToUpdate)->update([
            'course_id' => $request->course_id,
            'student_id' => $request->student_id,
            'ca' => $request->ca,
            'exam' => $request->exam,
            'total' => $request->total,
            'lg' => $request->lg,
            'unit' => $course->unit,
            'title' => $course->title,
            'semester' => $request->semester,
            'session' => $request->session,
            'level_id' => $request->level_id,
            'department_id' => $request->department_id,
            'cp' => Utils::calCumulativePoint($course->unit, $request->total)
        ]);

        $cummulativePoint = $student->results()->where([
            'session' => $request->session,
            'semester' => $request->semester,
            'student_id' => $request->student_id
        ])->sum('cp');

        $cummulativeUnit = $student->results()->where([
            'session' => $request->session,
            'semester' => $request->semester,
            'student_id' => $request->student_id   
        ])->sum('results.unit');

        $gradePoint = GradePoint::firstOrNew([
            'student_id' => $request->student_id,
            'session' => $request->session,
            'semester' => $request->semester
        ]);

        $gradePoint->fill([
            'cu' => $cummulativeUnit,
            'cp' => $cummulativePoint,
            'gpa' => Utils::calGradePoint($cummulativePoint, $cummulativeUnit)
        ]);
        $gradePoint->save();

        $ccPoint = GradePoint::where('student_id', $request->student_id)->sum('cp');
        $ccUnit  = GradePoint::where('student_id', $request->student_id)->sum('cu');

        $cummulative = Cummulative::where('student_id', $request->student_id)->first();
        $cummulative->fill([
            'ccu' => $ccUnit,
            'ccp' => $ccPoint,
            'cgpa' => Utils::calGradePoint($ccPoint, $ccUnit)
        ]);
        $cummulative->save();        
    }
 
}
