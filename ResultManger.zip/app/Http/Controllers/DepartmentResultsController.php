<?php

namespace App\Http\Controllers;

use App\Level;
use App\Student;
use App\Department;
use Illuminate\Http\Request;

class DepartmentResultsController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

    public function index()
    {
    	$departments = Department::all();
        return view('administrator.results.main', compact('departments'));
    }

    public function show(Department $department, Request $request)
    {      
        $level = Level::find($request->level);
        $session = $request->session;
        $semester = $request->semester;
        
        if ($level == NULL || $session == NULL || $semester == NULL) {
            $semester = 1;
            $session = 2015;
            $level = Level::find(1);
        }

        $classes = Level::all();

        // Get all courses offered by a level in a specific department and order the results by the course
        $courses = Level::find($level->id)->courses()->where([
            'semester_id' => $semester,
            'department_id' => $department->id
        ])->orderBy('course_id')->get();
    	
        // Gets all students in a level in a specific department
        $students = Student::where(['level_id' => $level->id, 'department_id' => $department->id])->orderBy('service_no')->get();

        $results = array();
        
        foreach($students as $student) {
            array_push($results, collect([
                'name' => $student->fullname, 
                'result' => $student->results()->where([
                    'level_id' => $level->id, 
                    'semester' => $semester, 
                    'session' => $session
                ])->orderBy('course_id')->get(),

                'grade_point' => $student->gradePoints()->where(['semester' => $semester, 'session' => $session])->first()
            ]));
        }

    	return view('administrator.results.all', compact('classes', 'level', 'semester', 'session', 'courses', 'results', 'department'));
    }

}
