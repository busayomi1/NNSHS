<?php

namespace App\Http\Controllers;

use App\Department;
use Illuminate\Http\Request;

class DepartmentResultsController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

    public function index()
    {
    	$departments = Department::all();
        return view('administrator.results.main', compact('departments'));
    }

    public function show(Department $department)
    {
    	$results = NULL;
    	return view('administrator.results.all', compact('results', 'department'));
    }

}
