<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Level;
use App\Department;
use App\Student;

class DepartmentsController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $departments = Department::all();
        return view('administrator.departments.all', compact('departments'));
    }

    public function create() 
    {
        return view('administrator.departments.create');
    }

    public function show(Department $department, Request $request) 
    {
        if($request->level) {
            $students = $this->filterByLevel($department, $request->level);
        }
        else {
            $students = $department->students;
        }        

        $levels = Level::all();
        return view('administrator.departments.students', compact('students', 'department', 'levels'));
    }

    public function edit(Department $department)
    {
        return view('administrator.departments.edit', compact('department'));
    }
    
    public function store(Request $request) 
    {
        $this->validate($request, [
            'name' => 'required',
            'code' => 'required'
        ]);

        Department::create($request->only(['name', 'code']));

        return redirect('/departments/create');
    }

    public function update(Department $department, Request $request) 
    {
        $this->validate($request, [
            'name' => 'required',
            'code' => 'required'
        ]);

        $department->fill($request->only(['name', 'code']));
        $department->save();

        return redirect('/departments');

    }


    private function filterByLevel($department, $level) 
    {
        return $department->students()
                        ->where('level_id', $level)
                        ->get();
    }

}
