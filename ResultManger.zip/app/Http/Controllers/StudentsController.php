<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Level;
use App\Rating;
use App\Result;
use App\Student;
use App\Department;
use App\Cummulative; 

class StudentsController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }
    
    public function index() 
    {
        $students = Student::all();
        return view('administrator.students.main', compact('students'));
    }

    public function create()
    {
        $levels = Level::all();
        $departments = Department::all();        
        return view('administrator.students.create', compact('departments', 'levels'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'fullname' => 'required',
            'service_no' => 'required',
            'department_id' => 'required'
        ]);

        $student = Student::create(
            $request->only(['service_no', 'fullname', 'level_id', 'department_id']));
        
        Cummulative::create(['student_id' => $student->id]);
        
        return redirect('/students/create');
    }

    public function edit(Student $student, Request $request) 
    {
        $levels = Level::all();
        $ratings = Rating::all();
        $departments = Department::all();

        if($request->service_no) {
            $student = Student::where('service_no', $request->service_no)->first();
        }

        return view('administrator.students.edit', compact('student', 'departments', 'ratings', 'levels'));        
    }

    public function update(Student $student, Request $request) 
    {
        $this->validate($request, [
            'fullname' => 'required',
            'service_no' => 'required',
            'level_id'  => 'required',
            'rate' => 'required',
            'department_id' => 'required'
        ]);

        $student->fill($request->only([
            'fullname', 'service_no', 'rate', 'department_id', 'level_id'
        ]));

        $student->save();

        return redirect("/students/$student->id/edit");
    }
}
