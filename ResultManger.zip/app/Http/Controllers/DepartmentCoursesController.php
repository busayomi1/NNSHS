<?php

namespace App\Http\Controllers;

use App\Level;
use App\Course;
use App\Semester;
use App\Department;
use Illuminate\Http\Request;

class DepartmentCoursesController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }

    public function index(Department $department) 
    {
        $courses = $department->courses;
        return view('administrator.dept_courses.all', compact('courses', 'department'));
    }

    public function edit(Department $department, Course $course)
    {
        $levels = Level::all();
        $semesters = Semester::all();
        return view('administrator.dept_courses.edit', compact('levels', 'course', 'semesters', 'department'));
    }

    public function update(Request $request)
    {
        $this->validate($request,[
            'course' => 'required',
            'department' => 'required',
            'semester' => 'required',
            'level' => 'required'
        ]);
        $course = Course::find($request->course);
        $course->semester_id = $request->semester;
        $course->save();
    
        $rowToUpdate = $course->departments()->where('department_id', $request->department)->first()->pivot->id;
        $course->departments()->newPivot()->where('id', $rowToUpdate)->update([
            'level_id' => $request->level
        ]);

        return redirect("/departments/$request->department/courses");
    }   
}
