<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;
use App\Level;
use App\Department;
use App\Inclusive;

class CoursesController extends Controller
{    

    public function __construct() 
    {
        $this->middleware('auth');
    }

    public function index() 
    {
        $courses = Course::all();
        return view('administrator.courses.all', compact('courses'));        
    } 

    public function create() 
    {
        $levels = Level::all();
        $departments = Department::all();
        return view('administrator.courses.create', compact('departments', 'levels'));
    }

    public function update(Request $request) 
    {
        $this->validate($request, [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required',
            'course_id' => 'required'
        ]);

        $course = Course::find($request->course_id);
        $course->fill($request->only(['title', 'code', 'unit']));
        $course->save();

        foreach ($course->departments as $department) {
            $course->departments()->updateExistingPivot($department->id, [
                'title' => $request->title, 
                'code' => $request->code, 
                'unit' => $request->unit
            ]);
        }

        return redirect('/courses');
    }

    public function store(Request $request) 
    {
        $this->validate($request, [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required',
            'department_id' => 'required' 
        ]);

        $course = Course::create($request->only(['title', 'code', 'unit']));
        
        for($i = 0; $i < count($request->department_id); $i++) {
            $course->departments()->attach($request->department_id[$i], [
                'title' => $request->title, 
                'code' => $request->code, 
                'unit' => $request->unit
            ]);
        }

        return redirect('/courses/create');
    }

    public function show(Course $course) 
    {
        $departments = Department::all();
        return view('administrator.courses.edit', compact('course', 'departments'));
    }

}
