<?php

namespace App;

use App\Model;
use App\Student;

class Course extends Model
{
    //
    public function results()
    {
    	return $this->belongsToMany('App\Student', 'results')
            ->using('App\Result')
            ->withPivot('id', 'ca', 'exam', 'lg', 'cp', 'unit', 'title', 'total', 'semester', 'session');
    }

    public function departments()
    {
    	return $this->belongsToMany('App\Department')->withPivot('code', 'title', 'unit');
    }

    public function newPivot(\Illuminate\Database\Eloquent\Model $parent, array $attributes, $table, $exists, $using=NULL)
    {
        if ($parent instanceof Student) {
            return new Result($parent, $attributes, $table, $exists, $using);
        }
        return parent::newPivot($parent, $attributes, $table, $exists, $using);
    }
    
}
