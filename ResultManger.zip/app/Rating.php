<?php

namespace App;

use App\Model;

class Rating extends Model
{
    //
}
