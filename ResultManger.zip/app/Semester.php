<?php

namespace App;

use App\Model;

class Semester extends Model
{
    public function courses()
    {
        return $this->hasMany('App\Course', 'course_id');
    }
}
