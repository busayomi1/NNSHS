<?php

namespace App;

use App\Model;
use Illuminate\Support\Facades\DB;

class Department extends Model
{
    
    public function students() 
    {
        return $this->hasMany('App\Student');
    }

    public function courses() 
    {
        return $this->belongsToMany('App\Course')->withPivot('id', 'code', 'title', 'unit');
    }

}
