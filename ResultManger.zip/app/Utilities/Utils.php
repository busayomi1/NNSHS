<?php

namespace App\Utilities;

use App\Grade;

final class Utils 
{
  
  public static function calGradePoint($cumulativePoint, $cumulativeUnit)
  {
      return $cumulativePoint / $cumulativeUnit;
  }

  public static function calCumulativePoint($courseUnit, $totalScore)
  {
      $grades = Grade::all();

      foreach ($grades as $grade)
      {
          if ($totalScore >= $grade->lower_bound && $totalScore <= $grade->upper_bound)
            return $courseUnit * $grade->point;
      }
  }

}