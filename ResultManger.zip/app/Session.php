<?php

namespace App;

use App\Model;

class Session extends Model
{
    //
}
