<?php

namespace App;

use App\Model;

class Level extends Model
{
    //
    public function students() 
    {
    	return $this->hasMany('App\Student');
    }
}
