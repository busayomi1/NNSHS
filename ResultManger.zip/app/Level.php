<?php

namespace App;

use App\Model;

class Level extends Model
{
    public function courses()
    {
         return $this->belongsToMany('App\Course', 'course_department')
            ->withPivot('id', 'department_id', 'code', 'title', 'unit');
    }

    public function students() 
    {
    	return $this->hasMany('App\Student');
    }
}
