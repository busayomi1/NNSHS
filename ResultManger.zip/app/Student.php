<?php

namespace App;

use App\Model;
use App\Course;

class Student extends Model
{
    public function department() 
    {
        return $this->belongsTo('App\Department');
    } 

    public function gradePoints()
    {
        return $this->hasMany('App\GradePoint', 'student_id');
    }

    public function cummulative()
    {
        return $this->hasOne('App\Cummulative', 'student_id');
    }

    public function level()
    {
    	return $this->belongsTo('App\Level');
    }

    public function results() 
    {
    	return $this->belongsToMany('App\Course', 'results')
            ->using('App\Result')
            ->withPivot('id', 'ca', 'exam', 'lg', 'cp', 'unit', 'title', 'total', 'semester', 'session');
    }

    public function newPivot(\Illuminate\Database\Eloquent\Model $parent, array $attributes, $table, $exists, $using=NULL)
    {
        if ($parent instanceof Course) {
            return new Result($parent, $attributes, $table, $exists, $using);
        }
        return parent::newPivot($parent, $attributes, $table, $exists, $using);
    }
}
