<?php

namespace App\Interfaces;

interface ResultProcessor
{
   public function saveResult();
   public function updateResult();
   public function updateGradePointAverage();
   public function updateCummulativeGradePointAverage();
}

