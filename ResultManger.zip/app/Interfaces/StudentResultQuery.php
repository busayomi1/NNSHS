<?php

namespace App\Interfaces;

use App\Course;
use App\Student;
use App\Department;
use App\GradePoint;
use App\Cummulative;
use App\Utilities\Utils;
use Illuminate\Http\Request;

class StudentResultQuery
{
    private $request;
    private $course;
    private $student;

    public function __construct(Request $request) 
    {
        $this->request = $request;
        $this->course = Course::find($request->course_id);
        $this->student = Student::find($request->student_id);
    }

    public function getResult()
    {
        return $this->student->results()->where([
            'session' => $this->request->session()->get('session'),
            'semester' => $this->request->session()->get('semester'),
            'course_id' => $this->request->session()->get('course_id')
        ])->first();
    }

    public function getCummulativePoint() 
    {
        return $this->student->results()->where([
                ['session', '=', $this->request->session],
                ['semester', '=', $this->request->semester],
                ['student_id', '=', $this->request->student_id]
            ])->sum('cp');
    }

    public function getCummulativeUnit() 
    {
        return $this->student->results()->where([
                ['session', '=', $this->request->session],
                ['semester', '=', $this->request->semester],
                ['student_id', '=', $this->request->student_id]
            ])->sum('results.unit');
    }

    public function getCombinedCummulativePoint() 
    {
        return GradePoint::where('student_id', $this->request->student_id)->sum('cp');
    }

    public function getCombinedCummulativeUnit() 
    {
        return GradePoint::where('student_id', $this->request->student_id)->sum('cu');
    }

    public function getGradePointForCurrentSemester()
    {
        return GradePoint::firstOrNew([
                'student_id' => $this->request->student_id,
                'session' => $this->request->session,
                'semester' => $this->request->semester
            ]);
    }

    public function getStudent() 
    {
        return $this->student;
    }

    public function getCourse() 
    {
        return $this->course;
    }

}

