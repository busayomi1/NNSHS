<?php

namespace App\Interfaces;

use App\Student;
use App\Department;
use App\GradePoint;
use App\Cummulative;
use App\Utilities\Utils;
use Illuminate\Http\Request;
use App\Interfaces\StudentResultQuery;

class StudentResultProcessor implements ResultProcessor
{
    private $query = NULL;
    private $request = NULL;

    public function __construct(Request $request) 
    {
        $this->request = $request;
        $this->query = new StudentResultQuery($request);
    } 
    
    public function saveResult() 
    {
        $course = $this->query->getCourse();
        $student = $this->query->getStudent();

        $student->results()->attach($this->request->course_id, [
            'ca' => $this->request->ca,
            'exam' => $this->request->exam,
            'total' => $this->request->total,
            'lg' => $this->request->lg,
            'unit' => $course->unit,
            'title' => $course->title,
            'semester' => $this->request->semester,
            'session' => $this->request->session,
            'level_id' => $this->request->level_id,
            'department_id' => $this->request->department_id,
            'cp' => Utils::calCumulativePoint($course->unit, $this->request->total)
        ]);
        
    }

    public function updateResult()
    {
        $course = $this->query->getCourse();
        $student = $this->query->getStudent();

        $result = $this->query->getResult();
        $rowIdToUpdate = $result->pivot->id;
        
        $student->results()->newPivot()->where('id', $rowIdToUpdate)->update([
            'course_id' => $this->request->course_id,
            'student_id' => $this->request->student_id,
            'ca' => $this->request->ca,
            'exam' => $this->request->exam,
            'total' => $this->request->total,
            'lg' => $this->request->lg,
            'unit' => $course->unit,
            'title' => $course->title,
            'semester' => $this->request->semester,
            'session' => $this->request->session,
            'level_id' => $this->request->level_id,
            'department_id' => $this->request->department_id,
            'cp' => Utils::calCumulativePoint($course->unit, $this->request->total)
        ]);
    }

    public function updateGradePointAverage()
    {
        $cummUnit = $this->query->getCummulativeUnit();
        $cummPoint = $this->query->getCummulativePoint();

        $gradePoint = $this->query->getGradePointForCurrentSemester();
        self::updateGradePointWithCummAndSave($gradePoint, $cummPoint, $cummUnit);
    }

    private static function updateGradePointWithCummAndSave($gradePoint, $cPoint, $cUnit)
    {
        $gradePoint->fill([
            'cu' => $cUnit,
            'cp' => $cPoint,
            'gpa' => Utils::calGradePoint($cPoint, $cUnit)
        ]);
        $gradePoint->save();
    }

    public function updateCummulativeGradePointAverage()
    {
        $ccUnit = $this->query->getCombinedCummulativeUnit();
        $ccPoint = $this->query->getCombinedCummulativePoint();

        $cummulative = Cummulative::where('student_id', $this->request->student_id)->first();
        $cummulative->fill([
            'ccu' => $ccUnit,
            'ccp' => $ccPoint,
            'cgpa' => Utils::calGradePoint($ccPoint, $ccUnit)
        ]);
        $cummulative->save();
    }
}

