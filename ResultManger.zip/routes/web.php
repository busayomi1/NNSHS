<?php

use App\Department;

/** Administrative Routes */
Route::get('/', 'AdminController@index')->name('home');


/** Student Management Routes **/
Route::get('/students','StudentsController@index');
Route::post('/students', 'StudentsController@store');
Route::get('/students/create', 'StudentsController@create');
Route::get('/students/{student}/edit', 'StudentsController@edit');
Route::post('/students/update/{student}', 'StudentsController@update');

/** Department Mangement Routes **/
Route::get('/departments','DepartmentsController@index');
Route::post('/departments', 'DepartmentsController@store');
Route::get('/departments/create', 'DepartmentsController@create');
Route::get('/departments/{department}/edit', 'DepartmentsController@edit');
Route::post('/departments/update/{department}', 'DepartmentsController@update');
Route::get('/departments/{department}/students/', 'DepartmentsController@show');

/** Courses manangement for Departments routes **/
Route::post('/departments/courses/', 'DepartmentCoursesController@update');
Route::get('/departments/{department}/courses', 'DepartmentCoursesController@index');
Route::get('/departments/{department}/courses/{course}/edit', 'DepartmentCoursesController@edit');

/** Course Management Routes */
Route::get('/courses', 'CoursesController@index');
Route::post('/courses', 'CoursesController@store');
Route::get('/courses/create', 'CoursesController@create');
Route::post('/courses/update', 'CoursesController@update');
Route::get('courses/update/{course}/', 'CoursesController@show');

/** Department Result Management Routes **/
Route::get('/results', 'DepartmentResultsController@index');
Route::get('/results/department/{department}', 'DepartmentResultsController@show');

/** Student Results Management Routes **/
Route::post('/results', 'StudentResultsController@store');
Route::post('/results/update', 'StudentResultsController@update');
Route::get('/results/{student}', 'StudentResultsController@show');
Route::get('/results/{department}/{student}/edit', 'StudentResultsController@edit');
Route::get('/results/{department}/{student}', 'StudentResultsController@create');

Route::get('/department/{department}/students', function(Department $department) {
	$students = $department->students;
	return view('administrator.results.students', compact('department','students'));
});

/** Session Management Routes **/
Route::get('/login', 'AuthController@login')->name('login');
Route::get('/logout', 'AuthController@destroy');
Route::post('/login', 'AuthController@store');
