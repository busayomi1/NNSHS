<?php

use Illuminate\Database\Seeder;

use App\Semester;

class SemesterTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Semester::create([
            'code' => 1, 
            'title' => 'First semester'
        ]);

        Semester::create([
            'code' => 2, 
            'title' => 'Second semester'
        ]);
    }
}
