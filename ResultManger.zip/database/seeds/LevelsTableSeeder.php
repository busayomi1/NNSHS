<?php

use App\Level;
use Illuminate\Database\Seeder;

class LevelsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Level::create([
        	'title' => 'Class One',
        	'code'	=> '100'
        ]);

        Level::create([
        	'title' => 'Class Two',
        	'code'	=> '200'
        ]);

        Level::create([
        	'title' => 'Class Three',
        	'code'	=> '300'
        ]);
    }
}
