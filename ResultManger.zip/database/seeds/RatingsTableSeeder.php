<?php

use App\Rating;
use Illuminate\Database\Seeder;

class RatingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Rating::create([
            'rating' => 'OSAMA'
        ]);

        Rating::create([
            'rating' => 'SMMA'
        ]);

        Rating::create([
            'rating' => 'ABMA'
        ]);

        Rating::create([
            'rating' => 'LSMA'
        ]);

        Rating::create([
            'rating' => 'POMA'
        ]);

        Rating::create([
            'rating' => 'WOMA'
        ]);

        Rating::create([
            'rating' => 'MWOMA'
        ]);

        Rating::create([
            'rating' => 'NWOMA'
        ]);
    }
}
