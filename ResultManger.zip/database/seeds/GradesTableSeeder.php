<?php

use App\Grade;
use Illuminate\Database\Seeder;

class GradesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Grade::create([
            'grade' => 'A',
            'point' => 4.00,
            'lower_bound' => 80,
            'upper_bound' => 100            
        ]);

        Grade::create([
            'grade' => 'B',
            'point' => 3.50,
            'lower_bound' => 70,
            'upper_bound' => 79            
        ]);

        Grade::create([
            'grade' => 'C',
            'point' => 3.00,
            'lower_bound' => 60,
            'upper_bound' => 69            
        ]);

        Grade::create([
            'grade' => 'D',
            'point' => 2.50,
            'lower_bound' => 50,
            'upper_bound' => 59            
        ]);

        Grade::create([
            'grade' => 'E',
            'point' => 2.00,
            'lower_bound' => 40,
            'upper_bound' => 49            
        ]);

        Grade::create([
            'grade' => 'F',
            'point' => 0.00,
            'lower_bound' => 0,
            'upper_bound' => 39
        ]);
    }
}
