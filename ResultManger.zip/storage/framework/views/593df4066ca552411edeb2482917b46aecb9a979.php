<?php $__env->startSection('content'); ?>
    
    <header class="greeting-text-frame">
        <h4>Quick links</h4>
        <div class="divider"></div>
    </header>

    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--4-col">
            <div class="demo-card-square mdl-card mdl-shadow--2dp">
                <div class="mdl-card__title">
                    <span class="mdl-title__text">Students</span>
                </div>
                <div class="mdl-card__supporting-text">
                   Manage students
                </div>
                <div class="mdl-card__actions mdl-card--border">
                    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">

                    </a>
                </div>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col">
            <div class="demo-card-square mdl-card mdl-shadow--2dp">
                 <div class="mdl-card__title">
                    Departments
                </div>
                 <div class="mdl-card__supporting-text">
                   Manage departments
                </div>
                <div class="mdl-card__actions mdl-card--border">
                    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        
                    </a>
                </div>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col">
            <div class="demo-card-square mdl-card mdl-shadow--2dp">
                 <div class="mdl-card__title">
                    Courses
                </div>
                 <div class="mdl-card__supporting-text">
                   Manage courses
                </div>
                <div class="mdl-card__actions mdl-card--border">
                    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        
                    </a>
                </div>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col">
            <div class="demo-card-square mdl-card mdl-shadow--2dp">
                 <div class="mdl-card__title">
                    Settings
                </div>
                 <div class="mdl-card__supporting-text">
                   Change administrative settings
                </div>
                <div class="mdl-card__actions mdl-card--border">
                    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>