<?php $__env->startSection('content'); ?>
  <section class="content">
    <header class="greeting-text-frame">
      <h4>Assign semester and level</h4>
      <div class="divider"></div>
      <div class="sub-controls">
        <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back</a>
      </div>
    </header>

    <div class="page-content-frame">
      <div>
        <form action="/departments/courses/" method="POST">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="course" value="<?php echo e($course->id); ?>">
          <input type="hidden" name="department" value="<?php echo e($department->id); ?>">
          
          <div style="margin: auto auto 30px auto">
            <h5 style="margin: auto auto 30px auto">Select semester to assign course</h5>
              <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label for="semester">
                <?php echo e($semester->title); ?>

                <input type="radio" checked name="semester" value="<?php echo e($semester->code); ?>">
              </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <div>
            <h5>Select level</h5>
            <label>
              <select name="level">
                  <option selected disabled>select level</option>
                  <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($level->id); ?>"><?php echo e($level->code); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </label>
          </div>
         

          <div style="padding: 30px 0px 30px 0px">
            <input class="mdl-button mdl-button--raised mdl-button--colored" type="submit" value="assign">
          </div>
        </form>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>