<?php $__env->startSection('css'); ?>
  <style>
    .error-container {
      color: #fff;
      width: 700px;
      text-align: center;
      border-radius: 4px;
      background: lightcoral;
      margin: 10% auto auto auto;
      padding: 20px 20px 35px 30px; 
    }

    .redirect-controls {
      color: #ffffff;
    }

    .redirect-controls > a {
      color: #ffffff;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="error-container">
    <h3>Duplicate record found</h3>  
    <h4>Please use the Edit option to change a particular result</h4>

    <h3>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h3>
    <div class="redirect-controls">
      <a href="/department/<?php echo e($department); ?>/students" class="mdl-button"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>