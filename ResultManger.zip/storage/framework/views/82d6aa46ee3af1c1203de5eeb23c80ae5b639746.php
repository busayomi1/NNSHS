<?php $__env->startSection('content'); ?>

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">Edit Student profile</h4>

            <div class="search-widget">
                <form class="search-form" action="" method="POST">
                    <div class="search-box">
                        <input type="text" name="service_no" placeholder="Service number">
                        <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit">
                            <span class="mdi mdi-account-search"></span>
                            search
                        </button>
                    </div>
                </form>
            </div>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/admin/student" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <!-- Update form -->
        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/" method="POST">
                
                <span class="mdi mdi-account form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="fullname" type="text" id="fullname">
                    <label class="mdl-textfield__label" for="username">Fullname</label>
                </div>

                <br>

                <span class="mdi mdi-account-card-details form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="service_no" type="text" id="service_no">
                    <label class="mdl-textfield__label" for="service_no">Service Number</label>
                </div>

                <br>

                <span class="mdi mdi-contacts form-icon"></span>
                <div class="select-field">
                    <select>
                        <option selected disabled>Please select level</option>
                        <option>100</option>
                        <option>200</option>
                        <option></option>
                        <option></option>
                    </select>
                </div>

                <br>

                <span class="mdi mdi-bank form-icon"></span>
                <div class="select-field">
                    <select name="department">
                        <option selected disabled>Please select department</option>
                        <option>Computer Science</option>
                        <option>Biochemistry</option>
                    </select>
                </div>

                <br>

                <span class="mdi mdi-poll form-icon"></span>
                <div class="select-field">
                    <select>
                        <option selected disabled>Select rating</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                    </select>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-account-edit"></span> update</button>
            </form>
        </div>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>