<?php $__env->startSection('content'); ?>
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage Departments</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments/create" class="mdl-button mdl-button--raised mdl-button--colored"><span class="mdi mdi-bank"></span>&nbsp;&nbsp; create department</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Id</th>
                        <th class="mdl-data-table__cell--non-numeric">Name</th>
                        <th class="mdl-data-table__cell--non-numeric">Code</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($department->id); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($department->name); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($department->code); ?></td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/departments/<?php echo e($department->id); ?>/edit" class="mdl-button mdl-button--colored">edit</a>
                                <a href="/departments/<?php echo e($department->id); ?>/students" class="mdl-button mdl-button--colored">view students</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>