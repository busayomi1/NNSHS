<?php $__env->startSection('content'); ?>

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">New course</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/courses" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <?php echo $__env->make('administrator.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/courses" method="POST">
                
                <?php echo e(csrf_field()); ?>


                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="text" name="title">
                    <label class="mdl-textfield__label" for="title">Title</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" name="code">
                    <label class="mdl-textfield__label" for="code">Code</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="number" name="unit">
                    <label class="mdl-textfield__label" for="unit">Unit</label>
                </div>

                <br>
               
                <div class="select-field">
                    <label style="color:red;">Hold the ctrl key to select multiple departments</label>
                    <select name="department_id[]" multiple>
                        <option selected disabled>Please select department</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="select-field">
                    <label style="color:red;">Hold the ctrl key to select multiple levels</label>
                    <select name="level_id[]" multiple>
                        <option selected disabled>Please select level</option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>"><?php echo e($level->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-clipboard-check"></span> create</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>