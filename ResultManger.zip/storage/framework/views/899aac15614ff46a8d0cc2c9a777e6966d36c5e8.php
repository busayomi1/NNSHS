<?php $__env->startSection('content'); ?>
    <div class="content">
         <header class="greeting-text-frame">
            <h4 class="greeting-title">Create Student</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/students" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>
        <?php echo $__env->make('administrator.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/students" method="POST">
                
                <?php echo e(csrf_field()); ?>


                <span class="mdi mdi-account form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="fullname" type="text" name="fullname">
                    <label class="mdl-textfield__label" for="username">Fullname</label>
                </div>

                <br>

                <span class="mdi mdi-account-card-details form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="service_no" type="text" name="service_no">
                    <label class="mdl-textfield__label" for="service_no">Service Number</label>
                </div>

                <br>

                <span class="mdi mdi-chart-line form-icon"></span>
                <div class="select-field">
                    <select name="level_id">
                        <option selected disabled>Please select level</option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level->id); ?>"><?php echo e($level->code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <br>

                <span class="mdi mdi-bank form-icon"></span>
                <div class="select-field">
                    <select name="department_id">
                        <option selected disabled>Please select department</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <br>

                <span class="mdi mdi-poll form-icon"></span>
                <div class="select-field">
                    <select name="rate">
                        <option selected disabled>Please select rating</option>
                        <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rating->rating); ?>"><?php echo e($rating->rating); ?></option>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-account-plus"></span> create</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>