<!Doctype html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <link href="/css/material.min.css" rel="stylesheet">
    <link href="/css/material-icons.css" rel="stylesheet">
    <link href="/css/fonts.css" rel="stylesheet">
    <link href="/css/sessions.css" rel="stylesheet">
  </head>
  
  <body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
    <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
        <div class="mdl-layout-spacer"></div>
    </header>
    <div class="mdl-layout__drawer">
        <span class="mdl-layout-title">Dashboard</span>
        <nav class="mdl-navigation">
            <a class="mdl-navigation__link" href="">Home</a>
            <a class="mdl-navigation__link" href="">Students</a>
            <a class="mdl-navigation__link" href="">Courses</a>
            <a class="mdl-navigation__link" href="">Results</a>
        </nav>
    </div>

    <!-- Scripts here -->
    <script src="/js/material.min.js"></script>
  </body>


</html>