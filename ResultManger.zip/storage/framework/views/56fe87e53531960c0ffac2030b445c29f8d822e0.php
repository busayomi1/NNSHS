<?php $__env->startSection('content'); ?>

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">New course</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/courses" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <div class="page-content-frame">
            <div class="">
            <form class="" action="/courses/update" method="POST">
                
                <?php echo e(csrf_field()); ?>

                <input name="course_id" value="<?php echo e($course->id); ?>" hidden/>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="text" name="title" value="<?php echo e($course->title); ?>">
                    <label class="mdl-textfield__label" for="title">Title</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" name="code" value="<?php echo e($course->code); ?>">
                    <label class="mdl-textfield__label" for="code">Code</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="number" name="unit" value="<?php echo e($course->unit); ?>">
                    <label class="mdl-textfield__label" for="unit">Unit</label>
                </div>

                <br>
                <!-- Departments go here -->

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-clipboard-outline"></span>&nbsp;&nbsp; update</button>
            </form>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>