<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="/css/material.min.css" rel="stylesheet">
        <link href="/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="/css/fonts.css" rel="stylesheet">
        <link href="/css/admin.css" rel="stylesheet">

        <style>

            .head {
                font-family: 'Roboto Bold';
            }
            .print_section {
                margin: 50px 70px 100px 805px;
            }
            .logo-text, .heading { 
                text-align: center;
            }
            
            .logo-text h3 { 
                display: inline-block;
            }

            .logo-text h5 {
                margin: -10px auto auto auto;
            }

            .content {
                padding: 50px;
                background: white;
                margin: auto;
            }

            .results_box {
                margin: -20px auto;
                width: 800px;
            }

            .semester-title {
                font-family: 'Roboto SemiBold';
                padding: 20px 0px 20px 0px;
            }

            .grade_points h5 {
                font-size: 16px;
                display: inline-block;
                padding: 10px 20px 10px 0px;
            }

            .name_details {
                margin: auto;
            }

            .filter {
                position: fixed;
                left: 1100px;
                top: 115px;
                z-index: 100;
                padding: 20px;;
                background: #efefef;
                border-radius: 2px;
            }

            .sub-form > * {
                display: block;
                margin: auto auto 10px auto;
            }

            .sub-form > label {
                margin-left: -5px;
            }

            .sub-form > button {
                margin: 15px auto 2px 1px;
            }

            .name_details {
                padding: 30px;
                text-align: center;
            }

            .name_details h3 {
                font-size: 29px;
                display: inline-block;
                padding: 10px 30px;
                font-family: 'Roboto SemiBold';
            }

            .name_details h6 {
                font-size: 14px;
                font-family: "Roboto SemiBold";
                margin-top: -10px;
            }

            @media  print {
                .filter {
                    display: none;
                }

                .print_section {
                    display: none;
                }
            }
        </style>

    </head>
    
    <body>
        <main class="content">
            <header class="logo-text">
                <img src="/images/logo.png" width="90" heigh="90">
                <h3>Nigerian Navy School of Health Sciences</h3>
                <h5>Irra Road, Offa Kwara State</h5>
            </header>
            
             <div class="name_details">
                <h3>Department of <?php echo e($department->name); ?></h4>
            </div>            

            <div class="filter">
                <form class="sub-form" action="/results/department/<?php echo e($department->id); ?>">

                    <label>Level</label>
                    <select name="level">
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($level->id == $class->id): ?>
                             <option selected value="<?php echo e($level->id); ?>"><?php echo e($level->title); ?></option>
                            <?php else: ?>
                             <option value="<?php echo e($class->id); ?>"><?php echo e($class->title); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                   
                    <label>Semester</label>
                    <select name="semester">
                        <?php for($i = 1; $i <= 2; $i++): ?>
                            <?php if($semester == $i): ?>
                                <option selected value="<?php echo e($semester); ?>"><?php echo e($semester); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>

                    <label>Session</label>
                    <select name="session">
                     <?php for($i = 2015; $i <= 2025; $i++): ?>
                        <?php if($session == $i): ?>
                         <option selected value="<?php echo e($session); ?>"><?php echo e($session); ?></option>
                        <?php else: ?>
                         <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endif; ?>
                     <?php endfor; ?>
                    </select>

                    <button class="mdl mdl-button mdl-button--raised mdl-button--colored">filter</button>
                </form>
            </div>

        <?php if([] !== $courses && [] !== $results): ?>
        <section class="results_box">
            <div>
                <h5 class="head"><?php echo e($level->title); ?></h5>
            </div>
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        
                        <strong>
                            <th class="mdl-data-table__cell--non-numeric">Service Number</th>
                        </strong>
                        
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <th class="mdl-data-table__cell--non-numeric"><?php echo e($course->code); ?></th>
                            </strong>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <th class="mdl-data-table__cell--non-numeric"><strong>GPA</strong></th>
                        
                    </tr>
                </thead>

                <tbody>
                    
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->get('service_no')); ?></td>
                        
                        <?php if([] !== $result->get('result')->all()): ?>
                            <?php $__currentLoopData = $result->get('result'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="mdl-data-table__cell--non-numeric">
                                <?php echo e($res->pivot->lg); ?>

                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php for($i = 0; $i < count($courses); $i++): ?> 
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e('-'); ?></td>
                            <?php endfor; ?>
                        <?php endif; ?>
                        
                        <td class="mdl-data-table__cell--non-numeric">
                            <?php echo e((null !== $result->get('grade_point')) 
                                ? number_format($result->get('grade_point')->gpa, 2) 
                                : '-'); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </section>
    
        <?php endif; ?>

        <section class="print_section">
            <a href="/department/<?php echo e($department->id); ?>/students" class="mdl-button mdl-button--colored">
                <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back
            </a>
            <button id="print" class="mdl mdl-button mdl-button--raised mdl-button--colored">print</button>            
        </section>

    </section>

        <script>
            window.addEventListener('load', function(event) {
                var printButton = document.getElementById('print');
                printButton.addEventListener('click', function(event) {
                    window.print();
                })
            })
        </script>
    </body>

</html>

   