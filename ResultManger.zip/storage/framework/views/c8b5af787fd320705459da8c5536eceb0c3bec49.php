<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="/css/material.min.css" rel="stylesheet">
        <link href="/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="/css/fonts.css" rel="stylesheet">
        <link href="/css/admin.css" rel="stylesheet">

        <style>
            .print_controls {
                float: right;
                margin: 50px 70px 100px 50px;
            }
            .logo-text, .heading { 
                text-align: center;
            }
            
            .logo-text h3 { 
                display: inline-block;
            }

            .heading h3 {
                margin: 40px auto;
                padding: 20px 100px 20px 100px;
            }

            .content {
                padding: 50px;
                background: white;
                margin: auto;
            }

            .results_box {
                margin: 10px auto;
                width: 800px;
            }

            .semester-title {
                font-family: 'Roboto SemiBold';
                padding: 20px 0px 20px 0px;
            }

            .grade_points h5 {
                font-size: 16px;
                display: inline-block;
                padding: 10px 20px 10px 0px;
            }

            .name_details {
                margin: auto;
            }

            .filter {
                position: absolute;
                left: 890px;
                top: 220px;
                z-index: 100;
            }

            .name_details {
                padding: 50px;
                text-align: center;
            }

            .name_details h3 {
                font-size: 29px;
                display: inline-block;
                padding: 10px 30px;
                font-family: 'Roboto SemiBold';
            }

            .name_details h6 {
                font-size: 14px;
                font-family: "Roboto SemiBold";
                margin-top: -10px;
            }

            @media  print {
                .filter {
                    display: none;
                }

                .print_controls {
                    display: none;
                }
            }
        </style>

    </head>
    
    <body>
        <main class="content">
            <header class="logo-text">
                <img src="/images/logo.png" width="90" heigh="90">
                <h3>Nigerian Navy School of Health Sciences</h3>
                <h5>Irra Road, Offa Kwara State</h5>
            </header>

            <header class="heading">
                <h5> session</h5>
            </header>

             <div class="name_details">
                <h3>Department of <?php echo e($department->name); ?></h4>
            </div>

            <div class="filter">
                <form class="sub-form" action="/results/<?php echo e($department->id); ?>" method="GET">
                   
                    <label>Semester</label>
                    <select name="semester">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    </select>

                    <label>Session</label>
                    <select name="session">
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    </select>

                    <button class="mdl mdl-button mdl-button--raised mdl-button--colored">search</button>
                </form>
            </div>

        <?php if($results): ?>
        <section class="results_box">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        
                    </tr>
                </thead>

                <tbody>
                                   
                </tbody>
            </table>
        </section>
        <?php endif; ?>
        <section class="print_section">
            <button id="print" class="mdl mdl-button mdl-button--raised mdl-button--colored">print</button>
        </section>

    </section>

        <script>
            window.addEventListener('load', function(event) {
                var printButton = document.getElementById('print');
                printButton.addEventListener('click', function(event) {
                    window.print();
                })
            })
        </script>
    </body>

</html>

   