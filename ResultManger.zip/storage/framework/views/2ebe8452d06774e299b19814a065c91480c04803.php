<!Doctype html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <link href="/css/material.min.css" rel="stylesheet">
    <link href="/css/fonts.css" rel="stylesheet">
    <link href="/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="/css/sessions.css" rel="stylesheet">
  </head>
  
  <body>
    <header class="logo-text">
      <img src="/images/logo.png" width="90" heigh="90">
      <h3>Nigerian Navy School of Health Sciences</h3>
      <h5>Irra Road, Offa Kwara State</h5>
    </header>

    <main>
      
      <div class="overlay"></div> <br>
      <div class="login-container">
        <!-- Login card container -->
        <div class="login-card mdl-card mdl-shadow--2dp centralize">
          
          <header class="title-strip">
            <h4>SignIn</h4>
          </header>

          <!-- Login form -->
          <form action="/" method="POST">

            <span class="mdi mdi-account form-icon"></span>
            <div class="mdl-textfield mdl-js-textfield">
              <input class="mdl-textfield__input" type="text" id="username">
              <label class="mdl-textfield__label" for="username">Username</label>
            </div>
            
            <br>

            <span class="mdi mdi-key form-icon"></span>
            <div class="mdl-textfield mdl-js-textfield">
              <input class="mdl-textfield__input" type="password" id="password">
              <label class="mdl-textfield__label" for="password">Password</label>
            </div>

            <br><br>

            <div>
              <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" type="submit">Login</button>
            </div>

          </form>

        </div>
      </div>

    </main>

    <!-- Scripts here -->
    <script src="/js/material.min.js"></script>
  </body>


</html>