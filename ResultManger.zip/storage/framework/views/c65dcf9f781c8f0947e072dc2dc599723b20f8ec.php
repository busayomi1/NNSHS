<?php $__env->startSection('content'); ?>
  <section class="content">
    <header class="greeting-text-frame">
      <h4>Courses offered</h4>
      <div class="divider"></div>
      <div class="sub-controls">
        <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back</a>
      </div>
    </header>

    <div class="page-content-frame">
      <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
          <thead>
              <tr>
                  <th class="mdl-data-table__cell--non-numeric">Id</th>
                  <th class="mdl-data-table__cell--non-numeric">Code</th>
                  <th class="mdl-data-table__cell--non-numeric">Title</th>
                  <th class="mdl-data-table__cell--non-numeric">Level</th>
                  <th class="mdl-data-table__cell--non-numeric">Semester</th>
                  <th class="mdl-data-table__cell--non-numeric">Action</th>
              </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="mdl-data-table__cell--non-numeric"><?php echo e($course->id); ?></td>
                <td class="mdl-data-table__cell--non-numeric"><?php echo e($course->code); ?></td>
                <td class="mdl-data-table__cell--non-numeric"><?php echo e($course->title); ?></td>
                <td class="mdl-data-table__cell--non-numeric">
                  <?php $__currentLoopData = $course->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($level->code ? $level->code : 'not assigned'); ?> &nbsp;
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="mdl-data-table__cell--non-numeric">
                  <span ><?php echo e($course->semester ? $course->semester->code : 'not assigned'); ?>

                  <span>
                </td>
                <td>
                  <a href="/departments/<?php echo e($department->id); ?>/courses/<?php echo e($course->id); ?>/edit" class="mdl-button mdl-button--colored">edit</a>
                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>