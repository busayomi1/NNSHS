<?php $__env->startSection('content'); ?>
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage Results</h4>
            <div class="divider"></div>
        </header>

        <?php if(count($departments) == 0): ?>
            <?php echo $__env->make('administrator.no_department', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        
        <div class="container">
            <div class="mdl-grid">
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mdl-cell mdl-cell--3-col">
                        <!-- Icon goes here-->
                        <div class="action-item-center">
                            <div><span class="mdi mdi-bank"></span></div><br>
                            <a href="/department/<?php echo e($department->id); ?>/students/" class="mdl-button mdl-button--colored"><?php echo e($department->name); ?></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>