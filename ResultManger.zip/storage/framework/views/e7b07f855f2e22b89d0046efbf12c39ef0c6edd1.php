<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="/css/material.min.css" rel="stylesheet">
        <link href="/css/materialdesignicons.min.css" rel="stylesheet">
        <link href="/css/fonts.css" rel="stylesheet">
        <link href="/css/admin.css" rel="stylesheet">

        <style>
            .print_controls {
                float: right;
                margin: 50px 70px 100px 50px;
            }
            .logo-text, .heading { 
                text-align: center;
            }
            
            .logo-text h3 { 
                display: inline-block;
            }

            .heading h3 {
                margin: 40px auto;
                padding: 20px 100px 20px 100px;
            }

            .content {
                padding: 50px;
                background: white;
                margin: auto;
            }

            .results_box {
                margin: 10px auto;
                width: 800px;
            }

            .semester-title {
                font-family: 'Roboto SemiBold';
                padding: 20px 0px 20px 0px;
            }

            .grade_points h5 {
                font-size: 16px;
                display: inline-block;
                padding: 10px 20px 10px 0px;
            }

            .name_details {
                margin: auto;
            }

            .filter {
                position: absolute;
                left: 900px;
                top: 300px;
                z-index: 100;
            }

            .name_details {
                text-align: center;
            }

            .name_details h3 {
                font-size: 29px;
                display: inline-block;
                padding: 10px 30px;
                font-family: 'Roboto SemiBold';
            }

            .name_details h6 {
                font-size: 14px;
                font-family: "Roboto SemiBold";
                margin-top: -10px;
            }

            @media  print {
                .filter {
                    display: none;
                }

                .print_controls {
                    display: none;
                }
            }
        </style>

    </head>
    
    <body>
        <main class="content">
            <header class="logo-text">
                <img src="/images/logo.png" width="90" heigh="90">
                <h3>Nigerian Navy School of Health Sciences</h3>
                <h5>Irra Road, Offa Kwara State</h5>
            </header>

            <header class="heading">
                <h3>Student Transcript</h3>
            </header>

             <div class="name_details">
                <h3><?php echo e($student->fullname); ?></h4>
                <h6><?php echo e($student->service_no); ?></h6>
            </div>

            <div class="filter">
                <form class="sub-form" action="/results/<?php echo e($student->id); ?>">
                   <label>Session</label>
                   <select name="session">
                        <?php for($i = 2015; $i < 2025; $i++): ?>
                            <?php if($session == $i): ?>
                                <option selected value="<?php echo e($session); ?>"><?php echo e($session); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                   </select>

                   <button class="mdl mdl-button mdl-button--raised mdl-button--colored">filter</button>
                </form>
            </div>
            
             <section class="results_box">
                <?php if(count($resultsSemesterOne)): ?>
                    <h4 class="semester-title">First Semester</h4>
                    <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                        <thead>
                            <tr>
                                <th class="mdl-data-table__cell--non-numeric">Course Title</th>
                                <th class="mdl-data-table__cell--non-numeric">Unit</th>
                                <th class="mdl-data-table__cell--non-numeric">Total Score</th>
                                <th class="mdl-data-table__cell--non-numeric">Grade</th>
                                <th class="mdl-data-table__cell--non-numeric">Cummulative Point</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $resultsSemesterOne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->code); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->unit); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->total); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->lg); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->cp); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="grade_points">
                        <h5><strong>CU:</strong> <?php echo e($gradePointSemOne->cu); ?></h5>
                        <h5><strong>CP:</strong> <?php echo e($gradePointSemOne->cp); ?></h5>
                        <h5><strong>GP:</strong> <?php echo e(number_format($gradePointSemOne->gpa, 2)); ?></h5>
                    </div>
                <?php endif; ?>

                <br>
                
                <?php if(count($resultsSemesterTwo)): ?>
                    <h4 class="semester-title">Second Semester</h4>
                    <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                        <thead>
                            <tr>
                                <th class="mdl-data-table__cell--non-numeric">Course Title</th>
                                <th class="mdl-data-table__cell--non-numeric">Unit</th>
                                <th class="mdl-data-table__cell--non-numeric">Total Score</th>
                                <th class="mdl-data-table__cell--non-numeric">Grade</th>
                                <th class="mdl-data-table__cell--non-numeric">Cummulative Point</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $resultsSemesterTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->title); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->unit); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->total); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->lg); ?></td>
                                <td class="mdl-data-table__cell--non-numeric"><?php echo e($result->pivot->cp); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="grade_points">
                        <h5><strong>CU:</strong> <?php echo e($gradePointSemTwo->cu); ?></h5>
                        <h5><strong>CP:</strong> <?php echo e($gradePointSemTwo->cp); ?></h5>
                        <h5><strong>GP:</strong> <?php echo e(number_format($gradePointSemTwo->gpa, 2)); ?></h5>
                    </div>
                <?php endif; ?>
             </section>

            <?php if(count($resultsSemesterOne) || count($resultsSemesterTwo)): ?>
             <section class="results_box">
                <h5 class="semester-title"></h5>
                <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                    <thead>
                        <tr>
                            <th class="mdl-data-table__cell--non-numeric">Cummulative Unit (CCU)</th>
                            <th class="mdl-data-table__cell--non-numeric">Cummulative Point (CCP)</th>
                            <th class="mdl-data-table__cell--non-numeric">Cummulative Grade Point Average (CGPA)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($cummulative->ccu); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($cummulative->ccp); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e(number_format($cummulative->cgpa, 2)); ?></td>
                        </tr>
                    </tbody>
                </table>
             </section>
            <?php endif; ?>

            <section class="print_controls">
                <button id="print" class="mdl-button mdl-button--raised mdl-button--colored">print</button>
            </section>
        </main>
        <script>
            var PrintApp = {
                init: function() {
                var button = document.getElementById('print');
                
                button.addEventListener('click', function(event) {
                    window.print();
                }, false);
                }
            }

            window.addEventListener('load', function(event) {
                var app = Object.create(PrintApp);
                app.init();
            }, false);
         </script>
         
    </body>

</html>