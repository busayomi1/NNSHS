<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/** Administrative Routes */
Route::get('/', 'AdminController@index')->name('home');


/** Student Management Routes **/
Route::get('/students','StudentsController@index');
Route::post('/students', 'StudentsController@store');
Route::get('/students/create', 'StudentsController@create');
Route::post('/students/update', 'StudentsController@update');
Route::get('/students/update/{id?}', 'StudentsController@show');

/** Department Mangement Routes **/
Route::get('/departments','DepartmentsController@index');
Route::post('/departments', 'DepartmentsController@store');
Route::get('/departments/create', 'DepartmentsController@create');
Route::post('/departments/update', 'DepartmentsController@update');
Route::get('/departments/update/{department}', 'DepartmentsController@show');
Route::get('/departments/{department}/students/', 'DepartmentsController@showStudents');

/** Result Management Routes **/
Route::get('/results', 'ResultsController@index');
Route::post('/results', 'ResultsController@store');
Route::get('/results/{student}', 'ResultsController@getResult');
Route::get('/results/{student}/{department}', 'ResultsController@create');
Route::get('/department/{id}/students/', 'ResultsController@showStudents');

/** Course Management Routes */
Route::get('/courses', 'CoursesController@index');
Route::post('/courses', 'CoursesController@store');
Route::get('/courses/create', 'CoursesController@create');
Route::post('/courses/update', 'CoursesController@update');
Route::get('/courses/options', 'CoursesController@optionPage');
Route::get('courses/update/{course}/', 'CoursesController@show');

/**
 *  GET /students/create
 *  POST /students
 *  
 *  GET /departments
 *
 *
 */

/** Session Management Routes **/
Route::get('/login', 'AuthController@login')->name('login');
Route::get('/logout', 'AuthController@destroy');
Route::post('/login', 'AuthController@store');