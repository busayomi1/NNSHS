<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts.base');
});

Route::get('/results/show/{id?}', 'ResultsController@show');

Route::post('/results', 'ResultsController@store');
Route::get('/result/update/{id}/{dept?}', 'ResultsController@index');

Route::get('/departments', 'DepartmentsController@index');
Route::get('/departments/{id}/{level?}', 'DepartmentsController@students');

Route::get('/student/create', 'StudentsController@index');
Route::post('/students', 'StudentsController@store');
