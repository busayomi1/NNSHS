

var Grader = {
    init: function() {
        let caInput = document.getElementById('continious_assesment');
        let examInput = document.getElementById('exam');
        let totalInput = document.getElementById('total');

        caInput.addEventListener('change', function(event) {
            let value = Number(event.target.value);
            if(value > 20) {
                event.target.value = 20;
                return;
            }

            let sum = Number(examInput.value) + value;
            sumScores(sum);
            changeGradeSelected(sum);                

        });

        examInput.addEventListener('change', function(event){
            let value = Number(event.target.value);
            if(value > 80) {
                event.target.value = 80;
                return;
            }

            let sum = Number(caInput.value) + value;
            sumScores(sum);
            changeGradeSelected(sum);


        });

    }
}

function sumScores(val) {
    document.getElementById('total').value = val;
}

function getGrade(score) {
    if (score >= 80 && score <= 100)
        return 'A';
    
    if (score >=70 && score <= 79)
        return 'B';

      if (score >= 60 && score <= 69)
        return 'C';

      if (score >= 50 && score <= 59)
        return 'D';

      if (score >= 40 && score <= 49)
        return 'E';  

      if (score >= 0 && score <= 39)
        return 'F';
}

function changeGradeSelected(score) {
    let grade = getGrade(score);
    let gradeInput = document.getElementById('grade');
    gradeInput.value = grade;
}

window.addEventListener('load', function(event) {
    let grader = Object.create(Grader);
    grader.init();
}, false);