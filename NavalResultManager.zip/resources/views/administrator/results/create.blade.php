@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Insert student record</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/department/{{ $department->id }}/students" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
            <div class="student-detail">
                <h4><span class="mdi mdi-account"></span>&nbsp;&nbsp;{{ $student->fullname }}</h4>
                <h6>{{ $student->service_no }}</h6>
            </div>
        </header>

        <div class="page-content-frame">
           <div class="demo-form-card mdl-card  form-container">
                <form action="/results" method="POST">
                    {{ csrf_field() }}
                    <input type="text" hidden name="student_id" value="{{ $student->id }}">
                    <input type="text" hidden name="dept_id" value="{{ $department->id }}">

                    <div class="select-field">
                        <select name="course_id">
                            <option selected disabled>Please select course</option>
                            @foreach($courses as $course)
                            <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="select-field">
                        <select name="session">
                            <option selected disabled>Please select session</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025">2025</option>
                        </select>
                    </div>

                    <div class="select-field">
                        <select name="semester">
                            <option selected disabled>Please select semester</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                        </select>
                    </div>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" id="continious_assesment" name="continious_assesment" required>
                        <label class="mdl-textfield__label" for="continious_assesment">CA Score</label>
                    </div>

                    <br>

                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                        <input class="mdl-textfield__input" type="number" id="exam" name="exam" required>
                        <label class="mdl-textfield__label" for="code">Exam score</label>
                    </div>

                     <br>

                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input" type="number" id="total" name="total" readonly>
                        <label class="mdl-textfield__label" for="code"></label>
                    </div>

                    <br>

                    <div class="select-field">
                        <div class="mdl-textfield mdl-js-textfield">
                            <input class="mdl-textfield__input" type="text" id="grade" name="grade" readonly>
                            <label class="mdl-textfield__label" for="grade"></label>
                        </div>
                    </div>

                    <br>
                    <br>

                    <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-folder-outline"></span>&nbsp;&nbsp;insert</button>
                </form>
           </div>
        </div>

        @include('administrator.errors')
    </div>

    @section('scripts')
        <script src="/js/grader.js"></script>
    @endsection
    
@endsection