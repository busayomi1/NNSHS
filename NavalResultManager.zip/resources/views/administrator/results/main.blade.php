@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage Results</h4>
            <div class="divider"></div>
        </header>

        @if(count($departments) == 0)
            @include('administrator.no_department')
        @endif
        
        <div class="container">
            <div class="mdl-grid">
                @foreach($departments as $department)
                    <div class="mdl-cell mdl-cell--3-col">
                        <!-- Icon goes here-->
                        <div class="action-item-center">
                            <div><span class="mdi mdi-bank"></span></div><br>
                            <a href="/department/{{ $department->id }}/students/" class="mdl-button mdl-button--colored">{{ $department->name }}</a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    
@endsection