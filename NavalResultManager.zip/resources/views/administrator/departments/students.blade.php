@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Department of {{ $department->name }}</h4>
            <form class="sub-form" action="/departments/{{ $department->id }}/students" method="GET">
                   
                   <label>Level</label>
                   <select name="level">
                        @for($i = 100; $i < 400; $i += 100)
                            @if($level == $i)
                                <option selected value="{{ $level }}">{{ $level }}</option>
                            @else
                                <option value="{{ $i }}">{{ $i }}</option>
                            @endif
                        @endfor
                   </select>

                   <button class="mdl mdl-button mdl-button--raised mdl-button--colored">filter</button>
                </form>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        <th class="mdl-data-table__cell--non-numeric">Level</th>
                        <th class="mdl-data-table__cell--non-numeric">Rate</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($students as $student)
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->service_no }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->fullname }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->level }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->rate }}</td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="#" class="mdl-button mdl-button--colored">view result</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    
@endsection