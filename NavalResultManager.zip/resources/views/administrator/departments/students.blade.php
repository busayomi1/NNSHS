@extends('administrator.master')

@section('content')
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Department of {{ $department->name }}</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        <th class="mdl-data-table__cell--non-numeric">Level</th>
                        <th class="mdl-data-table__cell--non-numeric">Rate</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($students as $student)
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->service_no }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->fullname }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->level }}</td>
                            <td class="mdl-data-table__cell--non-numeric">{{ $student->rate }}</td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="#" class="mdl-button mdl-button--colored">view result</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    
@endsection