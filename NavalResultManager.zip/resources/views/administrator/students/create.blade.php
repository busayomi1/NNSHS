@extends('administrator.master')

@section('content')
    <div class="content">
         <header class="greeting-text-frame">
            <h4 class="greeting-title">Create Student</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/students" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>
        @include('administrator.errors')
        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/students" method="POST">
                
                {{ csrf_field() }}

                <span class="mdi mdi-account form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="fullname" type="text" name="fullname">
                    <label class="mdl-textfield__label" for="username">Fullname</label>
                </div>

                <br>

                <span class="mdi mdi-account-card-details form-icon"></span>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" name="service_no" type="text" name="service_no">
                    <label class="mdl-textfield__label" for="service_no">Service Number</label>
                </div>

                <br>

                <span class="mdi mdi-chart-line form-icon"></span>
                <div class="select-field">
                    <select name="level">
                        <option selected disabled>Please select level</option>
                        <option value="100">One</option>
                        <option value="200">Two</option>
                        <option value="300">Three</option>
                    </select>
                </div>

                <br>

                <span class="mdi mdi-bank form-icon"></span>
                <div class="select-field">
                    <select name="dept_id">
                        <option selected disabled>Please select department</option>
                        @foreach($departments as $department)
                        <option value="{{ $department->id }}">{{ $department->name }}</option>
                        @endforeach
                    </select>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-account-plus"></span> create</button>
            </form>
        </div>
    </div>
@endsection