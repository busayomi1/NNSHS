@extends('administrator.master')

@section('content')

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">Edit Student profile</h4>

            <div class="search-widget">
                <form class="search-form" action="/students/update/">
                    <div class="search-box">
                        <input type="text" name="service_no" placeholder="Service number">
                        <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit">
                            <span class="mdi mdi-account-search"></span>
                            search
                        </button>
                    </div>
                </form>
            </div>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/students" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        @if($student)

            <!-- Update form -->
            <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
                <form class="" action="/students/update/{{ $student->id }}" method="POST">

                    {{ csrf_field() }}
                    
                    <span class="mdi mdi-account form-icon"></span>
                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input" name="fullname" type="text" name="fullname" value="{{$student->fullname}}">
                        <label class="mdl-textfield__label" for="username">Fullname</label>
                    </div>

                    <br>

                    <span class="mdi mdi-account-card-details form-icon"></span>
                    <div class="mdl-textfield mdl-js-textfield">
                        <input class="mdl-textfield__input" name="service_no" type="text" name="service_no" value="{{$student->service_no}}">
                        <label class="mdl-textfield__label" for="service_no">Service Number</label>
                    </div>

                    <br>

                    <span class="mdi mdi-contacts form-icon"></span>
                    <div class="select-field">
                        <select name="level">
                            <option selected value="{{ $student->level }}">{{ $student->level }}</option>
                            <option value="100">100</option>
                            <option value="200">200</option>
                            <option value="300">300</option>
                        </select>
                    </div>

                    <br>

                    <span class="mdi mdi-bank form-icon"></span>
                    <div class="select-field">
                        <select name="dept_id">
                            @foreach($departments as $department)
                                @if($department->id == $student->dept_id)
                                    <option selected value="{{ $department->id }}">{{ $department->name }}</option>    
                                    @continue;
                                @endif
                                <option value="{{ $department->id }}">{{ $department->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <br>

                    <span class="mdi mdi-poll form-icon"></span>
                    <div class="select-field">
                        <select name="rate">
                            <option selected value='{{ ($student->rate) ? $student->rate : "Please select rate" }}'>{{ ($student->rate) ? $student->rate : "Please select rate" }}</option>
                            @foreach($ratings as $rating)
                                <option value="{{ $rating->rating }}">{{ $rating->rating }}</option>
                            @endforeach
                        </select>
                    </div>

                    <br>
                    <br>

                    <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-account-edit"></span> update</button>
                </form>
            </div>

        @endif
        
    </div>

@endsection