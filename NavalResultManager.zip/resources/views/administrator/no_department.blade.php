<div class="info-message-frame">
    <h2 class="main-message">No departments created</h2>
    <h4 class="sub-message">Please create departments to continue</h4>
</div>