<!Doctype html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <link href="/css/material.min.css" rel="stylesheet">
    <link href="/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="/css/fonts.css" rel="stylesheet">
    <link href="/css/admin.css" rel="stylesheet">
  </head>
  
  <body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
    <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
            <div class="brand-frame">
                <img class="relaxed-image" src="/images/logo.png"/>
                <span class="title">Naval School of Health Sciences</span>
            </div> 
            <div class="mdl-layout-spacer"></div>
            <div>
                <span id="current-date">30th December 2014</span>
                <a href="/logout" class="mdl-button"><span class="mdi mdi-export white-icon"></span></a>
            </div>
        </div>
    </header>
    <div class="demo-mdl-layout__drawer mdl-layout__drawer">
        <span class="mdl-layout-title">Dashboard</span>
        <nav class="mdl-navigation">
            <a class="mdl-navigation__link" href="/"><span class="mdi mdi-city icon-medium"></span>&nbsp;&nbsp;Home</a>
            <a class="mdl-navigation__link" href="/students"><span class="mdi mdi-account-multiple icon-medium"></span>&nbsp;&nbsp;Students</a>
            <a class="mdl-navigation__link" href="/courses"><span class="mdi mdi-clipboard-text icon-medium"></span>&nbsp;&nbsp;Courses</a>
            <a class="mdl-navigation__link" href="/departments"><span class="mdi mdi-bank icon-medium"></span>&nbsp;&nbsp;Departments</a>
            <a class="mdl-navigation__link" href="/results"><span class="mdi mdi-folder-multiple icon-medium"></span>&nbsp;&nbsp;Results</a>
        </nav>
    </div>

    <main class="mdl-layout__content">
        <section class="page-content">
            @yield('content')
        </section>
    </main>

    <!-- Scripts here -->
    <script src="/js/material.min.js"></script>
    <script src="/js/utils.js"></script>
    @yield('scripts');
  </body>


</html>