@extends('layouts.master')

  @section('other_css')
    <style>
      .container {
         width: 1000px;
         min-height: 700px;
         background: white;
      }
    </style>
  @endsection


  @section('content')
    
    <br><br><br><br><br><br><br><br><br><br>
    <div class="container">
      
      <div>
        <form class="form-inline" method="GET" action="/results/show/">
          <div class="form-group">
            <label class="form-group" for="id" id="id">Enter student service number</label>
            <input type="text" name="id" class="form-group" placeholder="service number">
          </div>
          <div class="form-group">
            <input class="btn btn-primary" type="submit" value="submit">
          </div>
        </form>


        <br><br>

           @if($student) 
            <div>

              <h2>{{ $student->fullname }}</h2>
              <h5>CU: {{ $cummulatives->CU }}.00</h5>
              <h5>GPA: {{ $cummulatives->GPA }}.00</h5>
              <h5>CCU: {{ $cummulatives->CCU }}.00</h5>
              <h5>CCP: {{ $cummulatives->CCP }}.00</h5>
              <h5>CGPA: {{ $cummulatives->CGPA }}.00</h5>
            </div>
           @endif 
        
      </div>
    </div>
  
  @endsection


