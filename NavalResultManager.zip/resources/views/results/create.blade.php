@extends('layouts.base')

  @section('other_css')
    <style>
      .container {
        width: 600px;
      }
    </style>
  @endsection

  @section('content')
     <br><br><br><br><br><br><br><br><br>
     <div>
        <div class="container">

          <div>
            <span>
              {{ $student->fullname }} : {{ $student->service_number }}
            </span>
            
            <form method="POST" action="/results">

              {{ csrf_field() }}
              
              <div class="form-group">
                <label for="course" id="course">Select course</label>
                <select name="course">
                  
                  @foreach($courses as $course)
                    <option value="{{ $course->id }}">{{ $course->title }}</option>
                  @endforeach

                </select>
              </div>

              <div class="form-group">
                <label for="course" id="course">Select semester</label>
                <select name="semester">
                  
                  <option value="1">1</option>
                  <option value="2">2</option>

                </select>
              </div>

              <div class="form-group">
                <input type="number" name="continous_assesment" class="form-group" placeholder="CA"/>
              </div>

              <div class="form-group">
                <input type="number" name="exam" class="form-group" placeholder="Exam"/>
              </div>

              <div class="form-group">
                <input type="number" name="total" class="form-group" placeholder="Total"/>
              </div>

              <input type="number" value="{{$student->id}}" name="id" hidden/>

              <div class="form-group">
                <select name="grade">
                  <option>Select grade</option>
                  @foreach($grades as $grade)
                    <option value="{{ $grade->grade }}">{{ $grade->grade }}</option>
                  @endforeach
                </select>
              </div>

              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="update"/>
              </div>
              
              @include('layouts.error') 
            
            </form>
          
          
          </div>
        
        </div>
 
     </div>
    
  @endsection

  @section('scripts')

  @endsection