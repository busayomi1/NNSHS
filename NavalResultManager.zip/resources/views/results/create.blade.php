@extends('layouts.base')

  @section('other_css')
    <style>
      .container {
        width: 600px;
      }
    </style>
  @endsection

  @section('content')
     <br><br><br><br><br><br><br><br><br>
     <div>
        <div class="container">

          <div>
            <span>
              {{ $student->fullname }} : {{ $student->service_no }}
            </span>
            
            <form method="POST" action="/results">

              {{ csrf_field() }}
              
              <div class="form-group">
                <label for="course" id="course">Select course</label>
                <select name="course_id">
                  
                  @foreach($courses as $course)
                    <option value="{{ $course->course_id }}">{{ $course->course_name }}</option>
                  @endforeach

                </select>
              </div>

              <div class="form-group">
                <label for="session" id="session">Select session</label>
                <select name="session">
                  
                  <option value="2015">2015</option>
                  <option value="2016">2016</option>
                  <option value="2017">2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>

                </select>
              </div>

              <div class="form-group">
                <label for="course" id="course">Select semester</label>
                <select name="semester">
                  
                  <option value="1">1</option>
                  <option value="2">2</option>

                </select>
              </div>

              <div class="form-group">
                <input type="number" name="continious_assesment" class="form-group" placeholder="CA"/>
              </div>

              <div class="form-group">
                <input type="number" name="exam" class="form-group" placeholder="Exam"/>
              </div>

              <div class="form-group">
                <input type="number" name="total" class="form-group" placeholder="Total"/>
              </div>

              <input type="number" value="{{$student->id}}" name="student_id" hidden/>

              <div class="form-group">
                <select name="grade">
                  <option>Select grade</option>
                  @foreach($gradings as $grade)
                    <option value="{{ $grade->grade }}">{{ $grade->grade }}</option>
                  @endforeach
                </select>
              </div>

              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="update"/>
              </div>
              
              @include('layouts.error') 
            
            </form>
          
          
          </div>
        
        </div>
 
     </div>
    
  @endsection

  @section('scripts')

  @endsection