<div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u197-bw">
     <div id="u197"><!-- group -->
      <div class="clearfix" id="u197_align_to_page">
       <div class="clip_frame grpelem" id="u98"><!-- image -->
        <img class="block" id="u98_img" src="/images/logo-crop-u98.png" alt="" width="178" height="160"/>
       </div>
       <div class="clearfix grpelem" id="pu93-4"><!-- column -->
        <div class="clearfix colelem" id="u93-4"><!-- content -->
         <p>NIGERIAN NAVY SCHOOL OF HEALTH SCIENCES</p>
        </div>
        <div class="clearfix colelem" id="u104-4"><!-- content -->
         <p>Irra Road, Offa Kwara State</p>
        </div>
       </div>
      </div>
     </div>
    </div>