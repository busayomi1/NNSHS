@extends('layouts.master')


  @section('content')
    <div class="clearfix colelem" id="u172-5"><!-- content -->
      <p id="u172-3"><span id="u172">Welcome</span><span id="u172-2"> Admin</span></p>
      </div>
      <div class="clearfix colelem" id="pu160"><!-- group -->
      <a class="nonblock nontext rgba-background clearfix grpelem" id="u160" href="/student/create"><!-- column --><div class="clip_frame colelem" id="u166"><!-- image --><img class="block" id="u166_img" src="images/0115-users.png" alt="" width="86" height="76"/></div><div class="clearfix colelem" id="u163-4"><!-- content --><p id="u163-2"><span class="Stdt_Type" id="u163">STUDENT MANAGEMENT</span></p></div></a>
      <a class="nonblock nontext rgba-background clearfix grpelem" id="u199" href="/departments"><!-- column --><div class="clip_frame colelem" id="u183"><!-- image --><img class="block" id="u183_img" src="images/0047-stack.png" alt="" width="76" height="76"/></div><div class="clearfix colelem" id="u164-4"><!-- content --><p id="u164-2"><span class="Stdt_Type" id="u164">STUDENT RECORD</span></p></div></a>
      <a class="nonblock nontext rgba-background clearfix grpelem" id="u204" href="/results/show/"><!-- column --><div class="clip_frame colelem" id="u186"><!-- image --><img class="block" id="u186_img" src="images/0049-folder-open.png" alt="" width="76" height="76"/></div><div class="clearfix colelem" id="u165-4"><!-- content --><p id="u165-2"><span class="Stdt_Type" id="u165">VIEW STUDENT RECORD</span></p></div></a>
      </div>
      <div class="clearfix colelem" id="u205-4"><!-- content -->
      <p>Click on the above Icons, to perform Various Operations</p>
      </div>
      <div class="verticalspacer"></div>
      <div class="colelem" id="u105"><!-- custom html -->
      &copy Copyright 2017 Nigerian Navy School of Health Sciences <br /> All Rights Reserved. <br /> Designed By BornGlobal
    </div>

   </div>
      </div>
  @endsection

  @section('scripts')
    <!-- JS includes -->
        <script type="text/javascript">
        if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
      </script>
        <script type="text/javascript">
        window.jQuery || document.write('\x3Cscript src="/js/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
      </script>
        <script src="/js/museutils.js?183364071" type="text/javascript"></script>
        <script src="/js/jquery.watch.js?71412426" type="text/javascript"></script>
        <!-- Other scripts -->
        <script type="text/javascript">
        $(document).ready(function() { try {
      (function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
      for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
      typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Some files on the server may be missing or incorrect. Clear browser cache and try again. If the problem persists please contact website author.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
      /* body */
      Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
      Muse.Utils.prepHyperlinks(true);/* body */
      Muse.Utils.resizeHeight()/* resize height */
      Muse.Utils.fullPage('#page');/* 100% height page */
      Muse.Utils.showWidgetsWhenReady();/* body */
      Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
      } catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
      </script>
  @endsection
