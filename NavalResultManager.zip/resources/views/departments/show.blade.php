@extends('layouts.master')

   @section('other_css')
    <link rel="stylesheet" type="text/css" href="/css/student_record.css?217579469" id="pagesheet"/>

    <style>
      .container {
        width: 800px;
      }
    </style>
  @endsection

  @section('content') 
  
    <br><br><br><br><br><br><br><br><br>
    <div>
       
        <div class="container">
            <div style="text-align: center;">
              <h3>
                {{ $department->name }}
              </h3>
            </div>
            <div style="float: right">
            <form class="form-inline" action="/departments/{{$department->id}}/">
                  <div class="form-group">
                    <select class="select" name="level">
                      <option selected value="100">class one</option>
                      <option value="200">class two</option>
                      <option value="300">class three</option>
                    </select class="custom-select mb-2 mr-sm-2 mb-sm-0">
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="find">
                    </div>
                  
                  </div>
            </form>
          </div>

           <div>
             <table class="table">
             
              <thead>
                <th>id</th>
                <th>Fullname</th>
                <th>Level</th>
                <th>Rate</th>
                <th>Service number</th>
                <th>Edit result</th>
              </thead>

              <tbody>
                
                @foreach($students as $student)
                   <tr>
                    <td>{{ $student->id }}</td>
                    <td>{{ $student->fullname }}</td>
                    <td>{{ $student->level}}</td>
                    <td>{{ $student->rate }}</td>
                    <td> {{ $student->service_number }}</td>
                    <td><a href="/result/update/{{$student->id}}/{{ $department->id }}"><button class="btn btn-primary">edit</button></a></td>
                  <tr>
                @endforeach

              </tbody>
             
             </table>
           </div> 

        </div>
    </div>
    


  
  @endsection




  @section('scripts') 
  
     <!-- JS includes -->
      <script type="text/javascript">
      if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
    </script>
      <script type="text/javascript">
      window.jQuery || document.write('\x3Cscript src="/js/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
    </script>
      <script src="/js/museutils.js?183364071" type="text/javascript"></script>
      <script src="/js/jquery.watch.js?71412426" type="text/javascript"></script>
      <script src="/js/webpro.js?3803554875" type="text/javascript"></script>
      <script src="/js/musewpslideshow.js?242596657" type="text/javascript"></script>
      <script src="/js/jquery.museoverlay.js?493285861" type="text/javascript"></script>
      <script src="/js/touchswipe.js?4038331989" type="text/javascript"></script>
      <!-- Other scripts -->
      <script type="text/javascript">
      $(document).ready(function() { try {
    (function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
    for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
    typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Some files on the server may be missing or incorrect. Clear browser cache and try again. If the problem persists please contact website author.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
    /* body */
    Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
    Muse.Utils.prepHyperlinks(true);/* body */
    Muse.Utils.resizeHeight()/* resize height */
    Muse.Utils.initWidget('#pamphletu384', function(elem) { new WebPro.Widget.ContentSlideShow(elem, {contentLayout_runtime:'lightbox',event:'click',deactivationEvent:'none',autoPlay:false,displayInterval:3000,transitionStyle:'fading',transitionDuration:300,hideAllContentsFirst:true,shuffle:false,enableSwipe:true,resumeAutoplay:true,resumeAutoplayInterval:3000,playOnce:false,autoActivate_runtime:false}); });/* #pamphletu384 */
    Muse.Utils.fullPage('#page');/* 100% height page */
    Muse.Utils.showWidgetsWhenReady();/* body */
    Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
    } catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
    </script>
  
  @endsection