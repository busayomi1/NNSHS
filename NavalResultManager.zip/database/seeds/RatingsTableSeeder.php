<?php

use App\Rating;
use Illuminate\Database\Seeder;

class RatingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Rating::create([
            'rating' => 'Senior'
        ]);

        Rating::create([
            'rating' => 'Junior'
        ]);
    }
}
