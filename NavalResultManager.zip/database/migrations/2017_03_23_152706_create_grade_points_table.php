<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGradePointsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grade_points', function (Blueprint $table) {
            $table->increments('id');
            $table->integer("CU")->default(0);
            $table->double("CP", 4, 2)->default(0);
            $table->double("GPA", 4, 2)->default(0.0);
            $table->integer('session')->nullable();
            $table->integer("semester")->default(0);
            
            $table->integer('stud_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grade_points');
    }
}
