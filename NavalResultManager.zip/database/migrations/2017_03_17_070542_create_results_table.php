<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('results', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('CA')->nullable();
            $table->integer('EX')->nullable();
            $table->integer('TL')->nullable();
            $table->integer('CP')->nullable();
            $table->char('LG', 3)->nullable();
            $table->integer('unit')->nullable();
            $table->string('level')->nullable();
            $table->integer('semester')->nullable();
            $table->string('stud_id');
            $table->string('dept_id');
            $table->string('course_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('results');
    }
}
