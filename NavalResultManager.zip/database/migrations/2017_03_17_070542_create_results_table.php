<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('results', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('CA')->nullable();
            $table->integer('EX')->nullable();
            $table->integer('TL')->nullable();
            $table->double('CP', 4, 2)->nullable();
            $table->char('LG', 3)->nullable();
            $table->integer('course_unit')->nullable();
            $table->string('course_title')->nullable();
            $table->string('level')->nullable();
            $table->integer('semester')->nullable();
            $table->integer('session')->nullable();

            $table->integer('course_id');
            $table->integer('stud_id');

            $table->unique(['session', 'semester', 'course_id', 'stud_id']);            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('results');
    }
}
