/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "./";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 38);
/******/ })
/************************************************************************/
/******/ ({

/***/ 38:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(9);


/***/ }),

/***/ 9:
/***/ (function(module, exports) {



var Grader = {
    init: function init() {
        var caInput = document.getElementById('continious_assesment');
        var examInput = document.getElementById('exam');
        var totalInput = document.getElementById('total');

        caInput.addEventListener('change', function (event) {
            var value = Number(event.target.value);
            if (value > 20) {
                event.target.value = 20;
                return;
            }

            var sum = Number(examInput.value) + value;
            sumScores(sum);
            changeGradeSelected(sum);
        });

        examInput.addEventListener('change', function (event) {
            var value = Number(event.target.value);
            if (value > 70) {
                event.target.value = 70;
                return;
            }

            var sum = Number(caInput.value) + value;
            sumScores(sum);
            changeGradeSelected(sum);
        });
    }
};

function sumScores(val) {
    document.getElementById('total').value = val;
}

function getGrade(score) {
    if (score >= 75) return 'A';

    if (score >= 70 && score <= 74) return 'AB';

    if (score >= 65 && score <= 69) return 'B';

    if (score >= 60 && score <= 64) return 'BC';

    if (score >= 55 && score <= 59) return 'C';

    if (score >= 50 && score <= 54) return 'CD';

    if (score >= 45 && score <= 49) return 'D';

    if (score >= 40 && score <= 44) return 'E';

    if (score < 40) return 'F';
}

function changeGradeSelected(score) {
    var grade = getGrade(score);
    var gradeInput = document.getElementById('grade');
    gradeInput.value = grade;
}

window.addEventListener('load', function (event) {
    var grader = Object.create(Grader);
    grader.init();
}, false);

/***/ })

/******/ });