<?php $__env->startSection('content'); ?>

    <div class="content">
        <header class="greeting-text-frame">
            <h4 class="greeting-title">New Department</h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/departments" class="mdl-button mdl-button--colored">
                    <span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp;back
                </a>
            </div>
        </header>

        <div class="demo-form-card mdl-card mdl-shadow--2dp form-container">
            <form class="" action="/departments" method="POST">
                
                <?php echo e(csrf_field()); ?>


                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input"  type="text" name="name">
                    <label class="mdl-textfield__label" for="name">Title</label>
                </div>

                <br>

                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" name="code">
                    <label class="mdl-textfield__label" for="code">Code</label>
                </div>

                <br>
                <br>

                <button class="mdl-button mdl-button--raised mdl-button--colored" type="submit"><span class="mdi mdi-bank"></span> create</button>
            </form>
        </div>
        <?php echo $__env->make('administrator.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>