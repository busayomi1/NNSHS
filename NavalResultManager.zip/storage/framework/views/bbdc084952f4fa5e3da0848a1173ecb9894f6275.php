<?php $__env->startSection('content'); ?>
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Department of <?php echo e($department->name); ?></h4>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/results" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
        </header>

        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        <th class="mdl-data-table__cell--non-numeric">Level</th>
                        <th class="mdl-data-table__cell--non-numeric">Rate</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->service_no); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->fullname); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->level); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->rate); ?></td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/results/<?php echo e($student->id); ?>/<?php echo e($department->id); ?>" class="mdl-button mdl-button--colored">insert</a>
                                <a href="/results/<?php echo e($student->id); ?>" class="mdl-button mdl-button--colored">view</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>