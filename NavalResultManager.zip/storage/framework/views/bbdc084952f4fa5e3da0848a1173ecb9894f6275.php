<?php $__env->startSection('content'); ?>
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Department of <?php echo e($department->name); ?></h4>
            <form class="sub-form" action="/departments/<?php echo e($department->id); ?>/students" method="GET">
                   
                <label>Level</label>
                <select name="level">
                    <?php for($i = 100; $i < 400; $i += 100): ?>
                        <?php if($level === $i): ?>
                            <option selected value="<?php echo e($level); ?>"><?php echo e($level); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endif; ?>                        
                    <?php endfor; ?>
                </select>

                <button class="mdl mdl-button mdl-button--raised mdl-button--colored">filter</button>
            </form>
            <div class="divider"></div>
            <div class="sub-controls">
                <a class="mdl-button mdl-button--raised mdl-button--colored" href="#"><span class="mdi mdi-bank"></span>&nbsp;&nbsp;view all results</a>
                <a href="/results" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
        </header>
    <br>
        <div class="page-content-frame">
            <table class="demo-mdl-table mdl-data-table mdl-js-data-table mdl-shadow--2dp">
                <thead>
                    <tr>
                        <th class="mdl-data-table__cell--non-numeric">Service number</th>
                        <th class="mdl-data-table__cell--non-numeric">Fullname</th>
                        <th class="mdl-data-table__cell--non-numeric">Level</th>
                        <th class="mdl-data-table__cell--non-numeric">Rate</th>
                        <th class="mdl-data-table__cell--non-numeric">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->service_no); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->fullname); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->level); ?></td>
                            <td class="mdl-data-table__cell--non-numeric"><?php echo e($student->rate); ?></td>
                            <td class="mdl-data-table__cell--non-numeric">
                                <a href="/results/<?php echo e($student->id); ?>/<?php echo e($department->id); ?>" class="mdl-button mdl-button--colored">insert</a>
                                <a href="/results/<?php echo e($student->id); ?>" class="mdl-button mdl-button--colored">view</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>