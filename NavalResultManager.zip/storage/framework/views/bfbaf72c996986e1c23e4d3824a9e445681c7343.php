  <?php $__env->startSection('other_css'); ?>
    <style>
      .container {
        width: 600px;
      }
    </style>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>
     <br><br><br><br><br><br><br><br><br>
     <div>
        <div class="container">

          <div>
            <span>
              <?php echo e($student->fullname); ?> : <?php echo e($student->service_number); ?>

            </span>
            
            <form method="POST" action="/results">

              <?php echo e(csrf_field()); ?>

              
              <div class="form-group">
                <label for="course" id="course">Select course</label>
                <select name="course">
                  
                  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>

              <div class="form-group">
                <label for="course" id="course">Select semester</label>
                <select name="semester">
                  
                  <option value="1">1</option>
                  <option value="2">2</option>

                </select>
              </div>

              <div class="form-group">
                <input type="number" name="continous_assesment" class="form-group" placeholder="CA"/>
              </div>

              <div class="form-group">
                <input type="number" name="exam" class="form-group" placeholder="Exam"/>
              </div>

              <div class="form-group">
                <input type="number" name="total" class="form-group" placeholder="Total"/>
              </div>

              <input type="number" value="<?php echo e($student->id); ?>" name="id" hidden/>

              <div class="form-group">
                <select name="grade">
                  <option>Select grade</option>
                  <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($grade->grade); ?>"><?php echo e($grade->grade); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="update"/>
              </div>
              
              <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            
            </form>
          
          
          </div>
        
        </div>
 
     </div>
    
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>