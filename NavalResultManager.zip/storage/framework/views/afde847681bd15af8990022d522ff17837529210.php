<?php $__env->startSection('content'); ?>
    <div class="content">
       <header class="greeting-text-frame">
            <h4>Manage students</h4>
            <div class="divider"></div>
        </header>

        <div class="actions-frame">
            <div class="mdl-grid">
                <div class="mdl-cell mdl-cell--4-col">
                    <!-- Icon goes here-->
                    <div class="action-item">
                        <div><span class="mdi mdi-account-plus"></span></div>
                        <a href="/students/create" class="mdl-button mdl-button--colored">Create student</a>
                    </div>
                    
                </div>
                <div class="mdl-cell mdl-cell--4-col">
                    <div class="action-item">
                        <div><span class="mdi mdi-account-edit"></span></div>
                        <a href="/admin/student/update" class="mdl-button mdl-button--colored">Update student</a>
                    </div>
                </div>
                <div class="mdl-cell mdl-cell--4-col">
                    <div class="action-item">
                        <div><span class="mdi mdi-account-multiple"></span></div>
                        <button class="mdl-button mdl-button--colored">View students</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>