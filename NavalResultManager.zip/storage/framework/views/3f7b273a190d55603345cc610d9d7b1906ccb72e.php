<!DOCTYPE html>
<html class="html" lang="en-GB">
 <head>

    <script type="text/javascript">
    if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.watch.js", "index.css"], "outOfDate":[]};
  </script>
    
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
    <meta name="generator" content="2015.0.0.309"/>
    <link rel="shortcut icon" href="/images/favicon.ico?3903427922"/>
    <title>NNSHS | Nigeria Navy School of Health Sciences</title>
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="/css/site_global.css?227355463"/>
    <link rel="stylesheet" type="text/css" href="/css/master_a-master.css?3977766125"/>
    <link rel="stylesheet" type="text/css" href="/css/app.css"/>
    <link rel="stylesheet" type="text/css" href="/css/index.css?4224290641" id="pagesheet"/>

     <style>
       body { background-color: #0073A9; }
     </style>
    
    <?php echo $__env->yieldContent('other_css'); ?>
    
    <!-- Other scripts -->
    <script type="text/javascript">
    document.documentElement.className += ' js';
  </script>

  <?php echo $__env->yieldContent('other_scripts'); ?>

</head>


<body>

  <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <?php echo $__env->yieldContent('content'); ?>
    
      
      <?php echo $__env->yieldContent('scripts'); ?>
   
   </body>
</html>
