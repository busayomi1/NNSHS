<?php $__env->startSection('content'); ?>
    <section class="content">
        <header class="greeting-text-frame">
            <h4>Department of <?php echo e($department->name); ?></h4>
            <form class="sub-form" action="/departments/<?php echo e($department->id); ?>/students" method="GET">
                   
                <label>Semester</label>
                <select name="semester">
                   <option value="1">1</option>
                   <option value="2">2</option>
                </select>

                <label>Session</label>
                <select name="session">
                   <option value="2015">2015</option>
                   <option value="2016">2016</option>
                   <option value="2017">2017</option>
                   <option value="2018">2018</option>
                   <option value="2019">2019</option>
                   <option value="2020">2020</option>
                </select>

                <button class="mdl mdl-button mdl-button--raised mdl-button--colored">search</button>
            </form>
            <div class="divider"></div>
            <div class="sub-controls">
                <a href="/department/<?php echo e($department->id); ?>/students" class="mdl-button mdl-button--colored"><span class="mdi mdi-arrow-left"></span>&nbsp;&nbsp; back</a>
            </div>
        </header>

        <section class="container">
            <table>
                <thead>
                    <tr>
                    <?php $__currentLoopData = $departmentResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($results->course_title); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>

                <tbody>
                
                </tbody>
            </table>
        </section>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>