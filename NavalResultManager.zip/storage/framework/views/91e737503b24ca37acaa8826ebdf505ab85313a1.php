  <?php $__env->startSection('other_css'); ?>
    <style>
      .container {
         width: 1000px;
         min-height: 700px;
         background: white;
      }
    </style>
  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('content'); ?>
    
    <br><br><br><br><br><br><br><br><br><br>
    <div class="container">
      
      <div>
        <form class="form-inline" method="GET" action="/results/show/">
          <div class="form-group">
            <label class="form-group" for="id" id="id">Enter student service number</label>
            <input type="text" name="id" class="form-group" placeholder="service number">
          </div>
          <div class="form-group">
            <input class="btn btn-primary" type="submit" value="submit">
          </div>
        </form>


        <br><br>

           <?php if($student): ?> 
            <div>

              <h2><?php echo e($student->fullname); ?></h2>
              <h5>Grade point: <?php echo e($cummulatives->GPA); ?>.00</h5>
              <h5>CU: <?php echo e($cummulatives->CU); ?>.00</h5>
              <h5>GPA: <?php echo e($cummulatives->GPA); ?>.00</h5>
              <h5>CCU: <?php echo e($cummulatives->CCU); ?>.00</h5>
              <h5>CCP: <?php echo e($cummulatives->CCP); ?>.00</h5>
              <h5>CGPA: <?php echo e($cummulatives->CGPA); ?>.00</h5>
            </div>
           <?php endif; ?> 
        
      </div>
    </div>
  
  <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>