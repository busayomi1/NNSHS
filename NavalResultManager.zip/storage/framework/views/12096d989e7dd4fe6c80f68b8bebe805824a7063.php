  <?php $__env->startSection('other_css'); ?>
     <link rel="stylesheet" type="text/css" href="/css/student_mgmt.css?491146596" id="pagesheet"/>

     <style>
        .container {
            margin: auto auto auto 300px !important;
            width: 400px;
            min-height: 900px;
            padding: 1px 0px 30px 1px;
        }
     </style>
  <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
      <div class="clearfix colelem" id="pu350"><!-- group -->
        <div class="clip_frame grpelem" id="u350"><!-- image -->
          <img class="block" id="u350_img" src="/images/0003-home3.png" alt="" width="26" height="26"/>
        </div>
        <a class="nonblock nontext rgba-background clearfix grpelem" id="u348-4" href="/"><!-- content --><p>Back To Home</p></a>
        </div>
        <div class="clearfix colelem" id="u278-4"><!-- content -->
        <p id="u278-2"><span class="Heading" id="u278">Update Student Information</span></p>
        </div>
        <div class="clearfix colelem" id="ppamphletu232"><!-- group -->
        <div class="PamphletWidget clearfix grpelem" id="pamphletu232"><!-- none box -->
                  
            <div class="container">

              <?php if($student): ?>
                  <!-- -->
              <form method="POST" action="/students/update">
                
                <?php echo e(csrf_field()); ?>

                
                <div class="form-group">
                  <label for="firstname">Fullname</label>
                  <input type="text" class="form-control" name="fullname" value="<?php echo e($student->fullname); ?>">
                </div>

                <div class="form-group">
                  <label for="firstname">Service Number</label>
                  <input type="text" class="form-control" name="service_no" value="<?php echo e($student->service_no); ?>">
                </div>

                <div class="form-group">
                  <label for="firstname">Rate</label>
                  <input type="number" class="form-control" name="rate" value="<?php echo e(($student->rate) ? $student->rate : 0); ?>">
                </div>

                 <div class="form-group">
                  <label for="level">Department</label>
                  <select class="custom-select" name="dept_id">
                                              
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($department->id == $student->dept_id): ?>
                            <option selected value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>    
                            <?php continue; ?>;
                        <?php endif; ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </select>
                            

                <div class="form-group">
                  <input class="btn btn-primary" type="submit" class="form-control" value="update">
                </div>
                
                <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>             

              </form>
             
              <?php endif; ?>
              <!-- -->

              <?php if(!$student): ?>
                <div style="text-align: center">
                    <h2 style="color: deepskyblue">No record found</h2>
                </div>
              <?php endif; ?>



            </div>

            </div>
              
      

  <?php $__env->stopSection(); ?>
  
  <?php $__env->startSection('scripts'); ?>
      <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="/js/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="/js/museutils.js?183364071" type="text/javascript"></script>
  <script src="/js/jquery.watch.js?71412426" type="text/javascript"></script>
  <script src="/js/webpro.js?3803554875" type="text/javascript"></script>
  <script src="/js/musewpslideshow.js?242596657" type="text/javascript"></script>
  <script src="/js/jquery.museoverlay.js?493285861" type="text/javascript"></script>
  <script src="/js/touchswipe.js?4038331989" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Some files on the server may be missing or incorrect. Clear browser cache and try again. If the problem persists please contact website author.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.resizeHeight()/* resize height */
Muse.Utils.initWidget('#pamphletu232', function(elem) { new WebPro.Widget.ContentSlideShow(elem, {contentLayout_runtime:'stack',event:'click',deactivationEvent:'none',autoPlay:false,displayInterval:3000,transitionStyle:'fading',transitionDuration:500,hideAllContentsFirst:false,shuffle:false,enableSwipe:true,resumeAutoplay:true,resumeAutoplayInterval:3000,playOnce:false,autoActivate_runtime:false}); });/* #pamphletu232 */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>