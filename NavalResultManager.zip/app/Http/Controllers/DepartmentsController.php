<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Department;
use App\Student;

class DepartmentsController extends Controller
{
    //
    public function index()
    {
        $departments = Department::all();

        return view('departments.all', compact('departments'));
    }

    public function show() 
    {

    }

    public function students($id, $level = 100) 
    {

        if(request('level') != 0) 
        {
            $level = request('level');
        }

        $department = Department::find($id);
        $students = Department::find($id)
                        ->hasMany('App\Student', 'dept_id')
                        ->where('level', $level)->get();

        return view('departments.show', compact('students','department'));

    }
    
}
