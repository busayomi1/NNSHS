<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Department;
use App\Student;

class DepartmentsController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $departments = Department::all();
        return view('administrator.departments.all', compact('departments'));
    }

    public function create() 
    {
        return view('administrator.departments.create');
    }

    public function show(Department $department) 
    {
        return view('administrator.departments.edit', compact('department'));
    }
    
    public function store() 
    {
        $this->validate(request(), [
            'name' => 'required',
            'code' => 'required'
        ]);

        Department::create(request(['name', 'code']));

        return redirect('/departments/create');
    }

    public function update() 
    {
        $this->validate(request(), [
            'name' => 'required',
            'code' => 'required',
            'id'   => 'required'
        ]);

        $department = Department::find(request('id'));
        $department->name = request('name');
        $department->code = request('code');
        $department->save();

        return redirect('/departments');

    }

    public function showStudents($id)
    {
        $level = request('level');
        
        if ($level == null) 
            $students = $this->students($id);
        else 
            $students = $this->filterByClass($id, $level);
        
        $department = Department::find($id);
        
        return view('administrator.departments.students', compact('students', 'department', 'level'));
    }

    public function students($id) 
    {
        return Department::find($id)
                        ->hasMany('App\Student', 'dept_id')
                        ->get();
    }

    private function filterByClass($id, $level = 100) 
    {
        return Department::find($id)
                        ->hasMany('App\Student', 'dept_id')
                        ->where('level', $level)
                        ->get();
    }

}
