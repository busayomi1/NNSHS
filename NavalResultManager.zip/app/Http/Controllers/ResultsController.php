<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Grade;
use App\Student;
use App\Result;
use App\Course;
use App\GradePoint;
use App\Department;
use App\Cummulative;

use App\Utilities\Utils;


class ResultsController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }
    
    public function index()
    {
        $departments = Department::all();
        return view('administrator.results.main', compact('departments'));
    }

    public function create(Student $student, Department $department) 
    {
        $courses  = self::getAllCourses($department);
        $gradings = self::getGradingSystem();        

        return view('administrator.results.create', compact('courses', 'student', 'gradings', 'department')); 
    }

    public function getResult(Student $student)
    {
        $session = request('session');
        $department = Department::find(session('department'));
        
        if ($session == null) {
            $session = 2015;
        }
    
        $resultsSemesterOne = $student->hasMany('App\Result', 'stud_id')
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 1]
                                ])
                                ->get();
        $gradePointSemOne = $student->hasMany('App\GradePoint', 'stud_id')
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 1]
                                    ])
                                    ->first();

        $resultsSemesterTwo = $student->hasMany('App\Result', 'stud_id')
                                ->where([
                                    ['session', '=', $session],
                                    ['semester', '=', 2]
                                ])
                                ->get();

        $gradePointSemTwo = $student->hasMany('App\GradePoint', 'stud_id')
                                    ->where([
                                        ['session', '=', $session],
                                        ['semester', '=', 2]
                                    ])
                                    ->first();
        $cummulative = $student->hasOne('App\Cummulative', 'stud_id')->first();

        return view('results.view', compact(
            'student', 'session', 
            'resultsSemesterOne',
            'gradePointSemOne',
            'resultsSemesterTwo',
            'gradePointSemTwo',
            'cummulative',
            'department'));
    }

    public function store() 
    {
        $this->validate(request(), [
            'exam' => 'required',
            'grade' => 'required',
            'total' => 'required',
            'semester' => 'required',
            'session' => 'required',
            'course_id' => 'required',
            'student_id' => 'required',
            'continious_assesment' => 'required'
        ]);

        $exam = request('exam');
        $grade = request('grade');
        $session = request('session');
        $totalScore = request('total');
        $semester = request('semester');
        $courseId = request('course_id');
        $studentId = request('student_id');
        $departmentId = request('dept_id');
        $continiousAssesment = request('continious_assesment');

        $student = Student::find($studentId);
        $selectedCourse = Course::find($courseId);

        $resultObj = Result::firstOrNew([
            'course_id' => $courseId,
            'stud_id' => $studentId,
            'semester'  => $semester,
            'session' => $session
        ]);

        $resultObj->EX = $exam;
        $resultObj->LG = $grade;
        $resultObj->TL = $totalScore;
        $resultObj->session = $session;
        $resultObj->stud_id = $studentId;
        $resultObj->semester = $semester;
        $resultObj->course_id = $courseId;
        $resultObj->level = $student->level;
        $resultObj->CA = $continiousAssesment;
        $resultObj->course_unit = $selectedCourse->unit;
        $resultObj->course_title = $selectedCourse->title;
        $resultObj->CP = Utils::calCumulativePoint($selectedCourse->unit, $totalScore);

        $resultObj->save();

        $cummulativePoint = Result::where([
            ['session', '=', $session],
            ['semester', '=', $semester],
            ['stud_id', '=', $studentId]
        ])->sum('CP');


        $cummulativeUnit = Result::where([
            ['session', '=', $session],
            ['semester', '=', $semester],
            ['stud_id', '=', $studentId]
        ])->sum('course_unit');

        $gradePoint = GradePoint::firstOrNew([
            'stud_id' => $studentId,
            'session' => $session,
            'semester' => $semester
        ]);

        $gradePoint->CP = $cummulativePoint;
        $gradePoint->CU = $cummulativeUnit;
        $gradePoint->GPA = Utils::calGradePoint($cummulativePoint, $cummulativeUnit);
        $gradePoint->save();

        $ccPoint = GradePoint::where('stud_id', $studentId)->sum('CP');
        $ccUnit = GradePoint::where('stud_id', $studentId)->sum('CU');

        $cummulative = Cummulative::where('stud_id', $studentId)->first();
        $cummulative->CCU = $ccUnit;
        $cummulative->CCP = $ccPoint;
        $cummulative->CGPA = Utils::calGradePoint($ccPoint, $ccUnit);
        $cummulative->save();

        return redirect("/results/{$studentId}/{$departmentId}");
        
    }

    public function showStudents($id)
    {
        $department = \App\Department::find($id);
        $students = \App\Department::find($id)
                        ->hasMany('App\Student', 'dept_id')
                        ->get();

        return view('administrator.results.students', compact('students', 'department'));
    }

    private function processResult() 
    {
        
    }

    private function getStudent($id) 
    {
        return Student::find($id);
    }

    private function getGradingSystem()
    {
        return Grade::all();
    }

    private function getAllCourses($department) 
    {
        return $department->courses;
    }    
}
