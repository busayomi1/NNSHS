<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Grade;
use App\Student;
use App\Result;
use App\Course;
use App\Department;
use App\Cummulative;

use App\Utilities\Utils;

class ResultsController extends Controller
{
    private $studentId;
    private $student;
    
    //
    public function index($id, $dept=1) 
    {
        $this->studentId = $id;

        $student = Student::find($id);
        $grades  = Grade::all();
        
        $courses = Department::find($dept)->hasMany('App\Course', 'dept_id')->get();     


        return view('results.create', compact('student', 'courses', 'grades'));
    }

    public function show($id = 0)
    {        
        $student = Student::find(request('id'));
        $results = Result::where('stud_id', request('id'))->get();
        $cummulatives = Cummulative::where('student_id', request('id'))->first();
            
        return view('results.view', compact('student', 'results', 'cummulatives'));
    }

    public function store()
    {
        $this->validate(request(), [
            
            'course' => 'required',
            'semester' => 'required',
            'continous_assesment' => 'required',
            'exam' => 'required',
            'total' => 'required',
            'grade' => 'required'

        ]);

        $result = Student::find(request('id'))
                    ->hasMany('App\Result', 'stud_id')
                    ->where('course_id', request('course'))->first();

        $result->ca = request('continous_assesment');
        $result->ex = request('exam');
        $result->tl = request('total');
        $result->lg = request('grade');
        $result->course_id  = request('course');
        $result->semester   = request('semester');
        
        $course = Course::find(request('course'));
        $courseUnit = $course->unit;

        $result->cp = Utils::calculateCumulativePoint($courseUnit, request('total'));
        $result->save();


        // Update the student's gradepoint
        // get all the courses the student offers
        $results = Student::find(request('id'))->hasMany('App\Result', 'stud_id')->get();
        
        $cummulativeUnit = 0;
        $cummulativePoint = 0;

        foreach($results as $result)
        {
            $cummulativePoint += $result->CP; 
            $cummulativeUnit  += $result->unit;
        }

        $cumulative = \App\Cummulative::where('student_id', request('id'))->first();
        $cumulative->cu = $cummulativeUnit;
        $cumulative->gpa = Utils::calculateGradePoint($cummulativePoint, $cummulativeUnit);
        $cumulative->ccu = $cummulativeUnit;
        $cumulative->ccp = $cummulativePoint;
        $cumulative->cgpa = Utils::calculateGradePoint($cumulative->ccp, $cumulative->ccu);
        $cumulative->semester = request('semester');

        $cumulative->save();


        return redirect("/");
    }
    
}
