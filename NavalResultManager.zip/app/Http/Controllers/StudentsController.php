<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Result;
use App\Student;
use App\Department;

class StudentsController extends Controller
{
    private $resultObj;
    private $departments;

    function __construct() 
    {
        $this->resultObj = new Result;
        $this->departments = Department::all();
    }

    public function index() 
    {
        $departments = $this->departments;

        return view('students.create', compact('departments'));
    }

    public function store() 
    {

       $this->validate(request(), [
            'fullname' => 'required',
            'level' => 'required',
            'dept_id' => 'required',
            'service_number' => 'required'
       ]);

       $student = Student::create(request(['fullname', 'level', 'dept_id', 'service_number']));
       
       $result = new Result;
       $result->stud_id  =  $student->id;
       $result->dept_id  =  request('dept_id');
       $result->level    =  request('level');
       $result->save();

       $cummulative = new \App\Cummulative;
       $cummulative->student_id = $student->id;
       $cummulative->semester = 1;
       $cummulative->save();

       return redirect('/');
       
    }

}
