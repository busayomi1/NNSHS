<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Result;
use App\Student;
use App\Department;
use App\Cummulative; 

class StudentsController extends Controller
{
    public function __construct() 
    {
        $this->middleware('auth');
    }
    
    public function index() 
    {
        $students = Student::all();
        return view('administrator.students.main', compact('students'));
    }

    public function create()
    {
        $departments = Department::all();        
        return view('administrator.students.create', compact('departments'));
    }

    public function store()
    {
        $this->validate(request(), [
            'fullname' => 'required',
            'service_no' => 'required',
            'dept_id' => 'required'
        ]);

        $student = Student::create(request(['service_no', 'fullname', 'level', 'dept_id']));
        
        $cummulative = new Cummulative;
        $cummulative->stud_id = $student->id;
        $cummulative->save();

        return redirect('/students/create');
    }

    public function show($id = null) 
    {
        $departments = Department::all();
        
        $studentId = $id;
        $student = null;

        if ($studentId == null) 
        {
            $studentId = request('service_no');
            $student = Student::where('service_no', $studentId)->first();
        }
        else 
        {
            $student = Student::where('id', $studentId)->first();
        }

        return view('administrator.students.edit', compact('student', 'departments'));        
    }

    public function update() 
    {
        $this->validate(request(), [
            'fullname' => 'required',
            'service_no' => 'required',
            'rate' => 'required',
            'dept_id' => 'required'
        ]);

        $fullname = request('fullname');
        $service_no = request('service_no');
        $rate = request('rate');
        $department = request('dept_id');

        $student = Student::where('service_no', $service_no)->first();
        $student->fullname = $fullname;
        $student->service_no = $service_no;
        $student->rate = $rate;
        $student->dept_id = $department;
        $student->save();

        return redirect('/students/update/{}');
    }
}
