<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;
use App\Department;
use App\Inclusive;

class CoursesController extends Controller
{    

    public function __construct() 
    {
        $this->middleware('auth');
    }

    public function index() 
    {
        $courses = Course::all();

        return view('administrator.courses.all', compact('courses'));        
    } 

    public function create() 
    {
        $departments = Department::all();
        return view('administrator.courses.create', compact('departments'));
    }

    public function update() 
    {
        $this->validate(request(), [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required',
            'course_id' => 'required'
        ]);

        $courseId = request('course_id');
        $title = request('title');
        $code = request('code');
        $unit = request('unit');

        $course = Course::find($courseId);
        $course->title = $title;
        $course->code = $code;
        $course->unit = $unit;
        $course->save();

        $inclusive = new Inclusive;
        $inclusive->course_name = request('title');
        $inclusive->course_id = request('course_id');
        $inclusive->dept_id = request('dept_id');
        $inclusive->save();

        return redirect('/courses');
    }

    public function store() 
    {
        $this->validate(request(), [
            'title' => 'required',
            'code' => 'required',
            'unit' => 'required',
            'dept_id' => 'required' 
        ]);

        $course = Course::create(request(['title', 'code', 'unit']));
        
        $courseId = $course->id;
        $courseTitle  = request('title');
        $departmentId = request('dept_id');
         
        $inclusive = new Inclusive;
        $inclusive->course_name = $courseTitle;
        $inclusive->course_id = $courseId;
        $inclusive->dept_id = $departmentId;
        $inclusive->save();

        return redirect('/courses/create');
    }

    public function show(Course $course) 
    {
        $departments = Department::all();
        
        return view('administrator.courses.edit', compact('course', 'departments'));
    }

    public function optionPage() 
    {
        return view('courses.index');
    }

}
