<?php

namespace App;

use App\Model;

class GradePoint extends Model
{
    //
}
