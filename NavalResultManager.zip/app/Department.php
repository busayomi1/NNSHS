<?php

namespace App;

use App\Model;
use Illuminate\Support\Facades\DB;

class Department extends Model
{
    
    public function students() 
    {
        return $this->hasMany('App\Student', 'dept_id');
    }

    public function courses() 
    {
        return $this->hasMany('App\Inclusive', 'dept_id');
    }

    public function getResultForCourse($id)
    {
        return $this->hasMany('App\Result', 'dept_id')
                        ->where('course_id', $id)
                            ->get();
    }

    public function results($session = 2015, $semester = 1) 
    {
        return DB::table('students')
                        ->join('results', 'students.id', '=', 'results.stud_id')
                        ->join('cummulatives', 'students.id', '=', 'cummulatives.stud_id')
                        ->select('students.fullname', 'results.EX', 'results.CA', 'results.TL', 
                                    'results.CP', 'results.LG', 'results.course_unit', 'results.course_title',
                                    'cummulatives.CCU', 'cummulatives.CCP', 'cummulatives.CGPA')
                        ->where([
                            ['results.dept_id', '=', $this->id],
                            ['results.session', '=', $session],
                            ['results.semester', '=', $semester]
                        ])
                        ->get();
    }

    public function inclusives() {
        return $this->hasMany('App\Inclusive', 'dept_id');
    }

}
