<?php

namespace App;

use App\Model;

class Department extends Model
{
    
    public function students() 
    {
        return $this->hasMany('App\Student', 'dept_id');
    }

    public function courses() 
    {
        return $this->hasMany('App\Course', 'dept_id');
    }

    public function getResultForCourse($id)
    {
        return $this->hasMany('App\Result', 'dept_id')
                        ->where('course_id', $id)
                            ->get();
    }

}
