<?php

namespace App;

use App\Model;

class Result extends Model
{
    //
}
