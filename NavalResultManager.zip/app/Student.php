<?php

namespace App;

use App\Model;

class Student extends Model
{
    public function department() 
    {
        return $this->belongsTo('App\Department', 'dept_id');
    } 
        
}
