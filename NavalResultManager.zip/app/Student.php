<?php

namespace App;

use App\Model;

class Student extends Model
{
    //

    public function courses() 
    {
        $courses = $this->hasMany('App\Course', 'stud_id');
    }
}
